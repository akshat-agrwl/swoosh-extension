/* ================================================================
   Swoosh — Dashboard App

   This file is the brain of the dashboard. It:
   1. Talks to the Chrome extension (to read/close actual browser tabs)
   2. Groups open tabs by domain with a landing pages category
   3. Renders domain cards, banners, and stats
   4. Handles all user actions (close tabs, save for later, focus)
   ================================================================ */

'use strict';

// Escape user-controlled strings before inserting into innerHTML to prevent XSS.
function escHtml(s) {
  return (s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function faviconUrl(pageUrl, size = 32) {
  try {
    const u = new URL(chrome.runtime.getURL('/_favicon/'));
    u.searchParams.set('pageUrl', pageUrl);
    u.searchParams.set('size', String(size));
    return u.toString();
  } catch { return ''; }
}

// Distribute HTML cards into fixed columns (round-robin) so expanding
// a card only affects its own column, not the entire layout.
function distributeToColumns(cards, count) {
  const cols = Array.from({ length: count }, () => []);
  cards.forEach((html, i) => cols[i % count].push(html));
  return cols.map(c => `<div class="masonry-col">${c.join('')}</div>`).join('');
}

// Hide broken favicon images without inline event handlers (CSP-safe)
document.addEventListener('error', (e) => {
  if (!e.target?.classList?.contains('favicon-img')) return;
  const img = e.target;
  const textEl = img.closest('.page-chip')?.querySelector('.chip-text');
  const letter = (textEl?.textContent || '?')[0].toUpperCase();
  const avatar = document.createElement('span');
  avatar.className = 'chip-favicon favicon-fallback';
  avatar.textContent = letter;
  img.replaceWith(avatar);
}, true);

/* ----------------------------------------------------------------
   CHROME API LAYER

   This page runs directly as the new-tab extension page, so we can
   call chrome.tabs.* APIs directly without any postMessage bridge.
   ---------------------------------------------------------------- */

const INTERNAL_PREFIXES = ['chrome://', 'chrome-extension://', 'about:', 'edge://', 'brave://'];

let openTabs = [];

/**
 * fetchOpenTabs()
 * Reads all open tabs directly via chrome.tabs.query, enriched with
 * lastActivated timestamps from the background service worker.
 */
async function fetchOpenTabs() {
  try {
    const tabs = await chrome.tabs.query({});
    // Get lastActivated map from background
    let lastActivated = {};
    try {
      const resp = await chrome.runtime.sendMessage({ type: 'getTabActivity' });
      if (resp && resp.lastActivated) lastActivated = resp.lastActivated;
    } catch (e) { console.warn('[swoosh] getTabActivity failed:', e); }

    openTabs = tabs
      .filter(t => {
        const url = t.url || '';
        if (url === 'chrome://newtab/' || url === 'edge://newtab/' || url === 'about:newtab') return true;
        if (url === 'chrome://extensions/' || url === 'edge://extensions/') return true;
        return !INTERNAL_PREFIXES.some(p => url.startsWith(p));
      })
      .map(t => ({ ...t, lastActivated: lastActivated[t.id] || null }));

  } catch (e) {
    console.warn('[swoosh] fetchOpenTabs failed:', e);
    openTabs = [];
  }
}

/**
 * closeTabsByUrls(urls, exact)
 * Closes all tabs whose URL matches the given list.
 */
async function closeTabsByUrls(urls, exact = false) {
  if (!urls || urls.length === 0) return;
  const urlSet = new Set(urls);
  const all = await chrome.tabs.query({});
  const ids = all
    .filter(t => exact ? urlSet.has(t.url) : urls.some(u => t.url && t.url.startsWith(u.replace(/\/$/, ''))))
    .map(t => t.id);
  if (ids.length > 0) await chrome.tabs.remove(ids);
  await fetchOpenTabs();
}

/**
 * focusTabsByUrls(urls)
 * Switches to the first tab matching one of the given URLs.
 */
async function focusTabsByUrls(urls) {
  if (!urls || urls.length === 0) return;
  const all = await chrome.tabs.query({});
  const currentWindow = await chrome.windows.getCurrent();
  for (const url of urls) {
    // Prefer tabs in other windows first (not behind this new tab page)
    let match = all.find(t => t.url === url && t.windowId !== currentWindow.id);
    if (!match) match = all.find(t => t.url === url);
    if (!match) match = all.find(t => { try { return new URL(t.url).hostname === new URL(url).hostname; } catch { return false; } });
    if (match) {
      await chrome.tabs.update(match.id, { active: true });
      await chrome.windows.update(match.windowId, { focused: true });
      return;
    }
  }
}

/**
 * closeDuplicates(urls, keepOne)
 * For each URL, closes duplicate tabs (optionally keeping one).
 */
async function closeDuplicates(urls, keepOne = true) {
  const all = await chrome.tabs.query({});
  const ids = [];
  for (const url of urls) {
    const matching = all.filter(t => t.url === url);
    if (keepOne) {
      const keep = matching.find(t => t.active) || matching[0];
      for (const t of matching) { if (t.id !== keep.id) ids.push(t.id); }
    } else {
      matching.forEach(t => ids.push(t.id));
    }
  }
  if (ids.length > 0) await chrome.tabs.remove(ids);
  await fetchOpenTabs();
}

// Listen for tab-change notifications from the background service worker.
let refreshTimer = null;
chrome.runtime.onMessage.addListener((msg) => {
  if (msg && msg.type === 'tabsChanged') {
    if (refreshTimer) clearTimeout(refreshTimer);
    refreshTimer = setTimeout(() => {
      refreshTimer = null;
      lastTabSnapshot = '';
      renderDashboard();
    }, 300);
  }
});

// Re-render when the user switches back to this tab — covers the case where
// a deferred link was opened in a new tab and the message was missed while
// this page was backgrounded.
document.addEventListener('visibilitychange', () => {
  if (document.visibilityState === 'visible') {
    lastTabSnapshot = '';
    renderDashboard();
  }
});


/* ----------------------------------------------------------------
   UI HELPERS
   ---------------------------------------------------------------- */

/**
 * showToast(message)
 *
 * Shows a brief pop-up notification at the bottom of the screen.
 * Like the little notification that pops up when you send a message.
 */
let _audioCtx = null;
function getAudioCtx() {
  if (!_audioCtx || _audioCtx.state === 'closed') {
    _audioCtx = new (window.AudioContext || window.webkitAudioContext)();
  }
  return _audioCtx;
}

function playCloseSound() {
  try {
    const ctx = getAudioCtx();
    if (ctx.state === 'suspended') ctx.resume();
    const t = ctx.currentTime;

    const duration = 0.25;
    const buffer = ctx.createBuffer(1, ctx.sampleRate * duration, ctx.sampleRate);
    const data = buffer.getChannelData(0);

    for (let i = 0; i < data.length; i++) {
      const pos = i / data.length;
      const env = pos < 0.1 ? pos / 0.1 : Math.pow(1 - (pos - 0.1) / 0.9, 1.5);
      data[i] = (Math.random() * 2 - 1) * env;
    }

    const source = ctx.createBufferSource();
    source.buffer = buffer;

    const filter = ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.Q.value = 2.0;
    filter.frequency.setValueAtTime(4000, t);
    filter.frequency.exponentialRampToValueAtTime(400, t + duration);

    const gain = ctx.createGain();
    gain.gain.setValueAtTime(0.15, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + duration);

    source.connect(filter).connect(gain).connect(ctx.destination);
    source.start(t);
  } catch {
    // Audio not supported
  }
}

/**
 * shootConfetti(x, y)
 *
 * Shoots a burst of colorful confetti particles from the given screen
 * coordinates (typically the center of a card being closed).
 *
 * Each particle:
 * - Is either a circle or a square (randomly chosen)
 * - Uses the dashboard's color palette: amber, sage, slate, with some light variants
 * - Flies outward in a random direction with a gravity arc
 * - Fades out over ~800ms, then is removed from the DOM
 *
 * Pure CSS + JS, no libraries.
 */
function shootConfetti(x, y) {
  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  // Color palette drawn from the dashboard's CSS variables
  const colors = [
    '#4149d8', // primary
    '#8a92f0', // primary light
    '#5a7a62', // sage
    '#8aaa92', // sage light
    '#5a6b7a', // slate
    '#8a9baa', // slate light
    '#d4b896', // warm paper
    '#b35a5a', // rose
  ];

  const particleCount = 17;

  for (let i = 0; i < particleCount; i++) {
    const el = document.createElement('div');

    // Randomly decide: circle or square
    const isCircle = Math.random() > 0.5;
    const size = 5 + Math.random() * 6; // 5–11px

    // Pick a random color from the palette
    const color = colors[Math.floor(Math.random() * colors.length)];

    // Style the particle
    el.style.cssText = `
      position: fixed;
      left: ${x}px;
      top: ${y}px;
      width: ${size}px;
      height: ${size}px;
      background: ${color};
      border-radius: ${isCircle ? '50%' : '2px'};
      pointer-events: none;
      z-index: 9999;
      transform: translate(-50%, -50%);
      opacity: 1;
    `;
    document.body.appendChild(el);

    // Physics: random angle and speed for the outward burst
    const angle  = Math.random() * Math.PI * 2;           // random direction (radians)
    const speed  = 60 + Math.random() * 120;              // px/second
    const vx     = Math.cos(angle) * speed;               // horizontal velocity
    const vy     = Math.sin(angle) * speed - 80;          // vertical: bias upward a bit
    const gravity = 200;                                   // downward pull (px/s²)

    const startTime = performance.now();
    const duration  = 700 + Math.random() * 200;          // 700–900ms

    // Animate with requestAnimationFrame for buttery-smooth motion
    function frame(now) {
      const elapsed = (now - startTime) / 1000; // seconds
      const progress = elapsed / (duration / 1000);

      if (progress >= 1) {
        el.remove();
        return;
      }

      // Position: initial velocity + gravity arc
      const px = vx * elapsed;
      const py = vy * elapsed + 0.5 * gravity * elapsed * elapsed;

      // Fade out during the second half of the animation
      const opacity = progress < 0.5 ? 1 : 1 - (progress - 0.5) * 2;

      // Slight rotation for realism
      const rotate = elapsed * 200 * (isCircle ? 0 : 1); // squares spin, circles don't

      el.style.transform = `translate(calc(-50% + ${px}px), calc(-50% + ${py}px)) rotate(${rotate}deg)`;
      el.style.opacity = opacity;

      requestAnimationFrame(frame);
    }

    requestAnimationFrame(frame);
  }
}

/**
 * animateCardOut(card)
 *
 * Smoothly removes a mission card in two phases:
 * 1. Fade out + scale down (GPU-accelerated, smooth)
 * 2. After fade completes, remove from DOM
 *
 * Also fires confetti from the card's center for a satisfying "done!" moment.
 */
function animateCardOut(card) {
  if (!card) return;

  // Get the card's center position on screen for the confetti origin
  const rect = card.getBoundingClientRect();
  const cx = rect.left + rect.width  / 2;
  const cy = rect.top  + rect.height / 2;

  // Shoot confetti from the card's center
  shootConfetti(cx, cy);

  // Phase 1: fade + scale down
  card.classList.add('closing');
  // Phase 2: remove from DOM after animation
  setTimeout(() => {
    card.remove();
    // After card is gone, check if the missions grid is now empty
    // and show the empty state if so
    checkAndShowEmptyState();
  }, 300);
}

function showToast(message) {
  const toast = document.getElementById('toast');
  document.getElementById('toastText').textContent = message;
  const undoBtn = document.getElementById('toastUndo');
  if (undoBtn) undoBtn.hidden = true;
  toast.classList.remove('has-undo');
  toast.classList.add('visible');
  setTimeout(() => toast.classList.remove('visible'), 2500);
}

function showActionToast(message, btnLabel, actionFn) {
  const toast   = document.getElementById('toast');
  const textEl  = document.getElementById('toastText');
  const undoBtn = document.getElementById('toastUndo');
  let dismissed = false;

  textEl.textContent = message;
  undoBtn.textContent = btnLabel;
  undoBtn.hidden = false;
  toast.classList.add('visible', 'has-undo');

  const dismiss = () => {
    if (dismissed) return;
    dismissed = true;
    toast.classList.remove('visible', 'has-undo');
    undoBtn.hidden = true;
    undoBtn.textContent = 'Undo';
    undoBtn.onclick = null;
    clearTimeout(timer);
  };

  undoBtn.onclick = () => { dismiss(); actionFn(); };
  const timer = setTimeout(dismiss, 6000);
}

function showUndoToast(message, undoFn) {
  const toast   = document.getElementById('toast');
  const textEl  = document.getElementById('toastText');
  const undoBtn = document.getElementById('toastUndo');
  let dismissed = false;

  textEl.textContent = message;
  undoBtn.hidden = false;
  toast.classList.add('visible', 'has-undo');

  const dismiss = () => {
    if (dismissed) return;
    dismissed = true;
    toast.classList.remove('visible', 'has-undo');
    undoBtn.hidden = true;
    undoBtn.onclick = null;
    clearTimeout(timer);
  };

  undoBtn.onclick = () => { dismiss(); undoFn(); };
  const timer = setTimeout(dismiss, 5000);
}

/**
 * checkAndShowEmptyState()
 *
 * Called after each card is removed from the DOM. If all mission cards
 * are gone (the grid is empty), we swap in a fun empty state instead of
 * showing a blank, lifeless grid.
 *
 */
function checkAndShowEmptyState() {

  const missionsEl = document.getElementById('openTabsMissions');
  if (!missionsEl) return;

  // Count remaining mission cards (excludes anything already animating out)
  const remaining = missionsEl.querySelectorAll('.mission-card:not(.closing)').length;
  if (remaining > 0) return;

  // All missions are gone — show the empty state
  missionsEl.innerHTML = `
    <div class="missions-empty-state">
      <div class="empty-checkmark">
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
          <path stroke-linecap="round" stroke-linejoin="round" d="m4.5 12.75 6 6 9-13.5" />
        </svg>
      </div>
      <div class="empty-title">Inbox zero, but for tabs.</div>
      <div class="empty-subtitle">You're free.</div>
    </div>
  `;

}

/**
 * timeAgo(dateStr)
 *
 * Converts an ISO date string into a human-friendly relative time.
 * e.g. "2026-04-04T10:00:00Z" → "2 hrs ago" or "yesterday"
 */
function timeAgo(dateStr) {
  if (!dateStr) return '';

  const then = new Date(dateStr);
  const now = new Date();
  const diffMs = now - then;
  const diffMins = Math.floor(diffMs / 60000);
  const diffHours = Math.floor(diffMs / 3600000);
  const diffDays = Math.floor(diffMs / 86400000);

  if (diffMins < 1)   return 'just now';
  if (diffMins < 60)  return diffMins + ' min ago';
  if (diffHours < 24) return diffHours + ' hr' + (diffHours !== 1 ? 's' : '') + ' ago';
  if (diffDays === 1) return 'yesterday';
  return diffDays + ' days ago';
}

/**
 * getGreeting()
 *
 * Returns an appropriate greeting based on the current hour.
 * Morning = before noon, Afternoon = noon–5pm, Evening = after 5pm.
 * No name — Swoosh is for everyone now.
 */
function getGreeting() {
  const hour = new Date().getHours();
  const morning   = ['Good morning', 'Rise and shine', 'Hello, sunshine', 'Morning!'];
  const afternoon = ['Good afternoon', 'Hope your day\'s going well', 'Afternoon!', 'Keep it up'];
  const evening   = ['Good evening', 'Wind down time', 'Evening!', 'Almost there'];
  const pool = hour < 12 ? morning : hour < 17 ? afternoon : evening;
  return pool[Math.floor(Math.random() * pool.length)];
}

function startClock() {
  const el = document.getElementById('clockDisplay');
  if (!el) return;
  function tick() {
    const now = new Date();
    const h = now.getHours() % 12 || 12;
    const m = String(now.getMinutes()).padStart(2, '0');
    const ampm = now.getHours() < 12 ? 'AM' : 'PM';
    el.textContent = `${h}:${m} ${ampm}`;
  }
  tick();
  setInterval(tick, 1000);
}

/* ----------------------------------------------------------------
   FREQUENT SITES + QUOTE + GOOGLE SEARCH
   ---------------------------------------------------------------- */


/* ----------------------------------------------------------------
   SVG ICON STRINGS

   We store these as a constant so we can reuse them in buttons
   without writing raw SVG every time. Each value is an HTML string
   ready to be injected with innerHTML.
   ---------------------------------------------------------------- */
/* ----------------------------------------------------------------
   DOMAIN & TITLE CLEANUP HELPERS

   Make domain names and tab titles more readable.
   - friendlyDomain() turns "github.com" into "GitHub"
   - cleanTitle() strips redundant site names from the end of titles
   ---------------------------------------------------------------- */

// Map of known domains → friendly display names.
// Covers the most common sites; everything else gets a smart fallback.
const FRIENDLY_DOMAINS = {
  'github.com':           'GitHub',
  'www.github.com':       'GitHub',
  'gist.github.com':      'GitHub Gist',
  'youtube.com':          'YouTube',
  'www.youtube.com':      'YouTube',
  'music.youtube.com':    'YouTube Music',
  'x.com':                'X',
  'www.x.com':            'X',
  'twitter.com':          'X',
  'www.twitter.com':      'X',
  'reddit.com':           'Reddit',
  'www.reddit.com':       'Reddit',
  'old.reddit.com':       'Reddit',
  'substack.com':         'Substack',
  'www.substack.com':     'Substack',
  'medium.com':           'Medium',
  'www.medium.com':       'Medium',
  'linkedin.com':         'LinkedIn',
  'www.linkedin.com':     'LinkedIn',
  'stackoverflow.com':    'Stack Overflow',
  'www.stackoverflow.com':'Stack Overflow',
  'news.ycombinator.com': 'Hacker News',
  'google.com':           'Google',
  'www.google.com':       'Google',
  'mail.google.com':      'Gmail',
  'docs.google.com':      'Google Docs',
  'drive.google.com':     'Google Drive',
  'calendar.google.com':  'Google Calendar',
  'meet.google.com':      'Google Meet',
  'gemini.google.com':    'Gemini',
  'chatgpt.com':          'ChatGPT',
  'www.chatgpt.com':      'ChatGPT',
  'chat.openai.com':      'ChatGPT',
  'claude.ai':            'Claude',
  'www.claude.ai':        'Claude',
  'code.claude.com':      'Claude Code',
  'notion.so':            'Notion',
  'www.notion.so':        'Notion',
  'figma.com':            'Figma',
  'www.figma.com':        'Figma',
  'slack.com':            'Slack',
  'app.slack.com':        'Slack',
  'discord.com':          'Discord',
  'www.discord.com':      'Discord',
  'wikipedia.org':        'Wikipedia',
  'en.wikipedia.org':     'Wikipedia',
  'amazon.com':           'Amazon',
  'www.amazon.com':       'Amazon',
  'netflix.com':          'Netflix',
  'www.netflix.com':      'Netflix',
  'spotify.com':          'Spotify',
  'open.spotify.com':     'Spotify',
  'vercel.com':           'Vercel',
  'www.vercel.com':       'Vercel',
  'npmjs.com':            'npm',
  'www.npmjs.com':        'npm',
  'developer.mozilla.org':'MDN',
  'arxiv.org':            'arXiv',
  'www.arxiv.org':        'arXiv',
  'huggingface.co':       'Hugging Face',
  'www.huggingface.co':   'Hugging Face',
  'producthunt.com':      'Product Hunt',
  'www.producthunt.com':  'Product Hunt',
  'xiaohongshu.com':      'RedNote',
  'www.xiaohongshu.com':  'RedNote',
  'local-files':          'Local Files',
};

/**
 * friendlyDomain(hostname)
 *
 * Turns a raw hostname into a human-readable name.
 * 1. Check the lookup map for known domains
 * 2. For subdomains of known domains, check if the parent matches
 *    (e.g. "docs.github.com" → "GitHub Docs")
 * 3. Fallback: strip "www.", strip TLD, capitalize
 *    (e.g. "minttr.com" → "Minttr", "blog.example.co.uk" → "Blog Example")
 */
function friendlyDomain(hostname) {
  if (!hostname) return '';

  // IP addresses — return as-is, they're already readable enough
  if (/^\d{1,3}(\.\d{1,3}){3}$/.test(hostname)) return hostname;

  // Direct lookup
  if (FRIENDLY_DOMAINS[hostname]) return FRIENDLY_DOMAINS[hostname];

  // Check for *.substack.com pattern (e.g. "lenny.substack.com" → "Lenny's Substack")
  if (hostname.endsWith('.substack.com') && hostname !== 'substack.com') {
    const sub = hostname.replace('.substack.com', '');
    return capitalize(sub) + "'s Substack";
  }

  // Check for *.github.io pattern
  if (hostname.endsWith('.github.io')) {
    const sub = hostname.replace('.github.io', '');
    return capitalize(sub) + ' (GitHub Pages)';
  }

  // Fallback: strip www, strip common TLDs, capitalize each word
  let clean = hostname
    .replace(/^www\./, '')
    .replace(/\.(com|org|net|io|co|ai|dev|app|so|me|xyz|info|us|uk|co\.uk|co\.jp|jio)$/, '');

  // If it's a subdomain like "blog.example", keep it readable
  return clean
    .split('.')
    .map(part => capitalize(part))
    .join(' ');
}

/**
 * capitalize(str)
 * "github" → "GitHub" (okay, just "Github" — but close enough for fallback)
 */
function capitalize(str) {
  if (!str) return '';
  return str.charAt(0).toUpperCase() + str.slice(1);
}

/**
 * stripTitleNoise(title)
 *
 * Removes common noise from browser tab titles:
 * - Leading notification counts: "(2) Vibe coding ideas" → "Vibe coding ideas"
 * - Trailing email addresses: "Subject - user@gmail.com" → "Subject"
 * - X/Twitter cruft: "Name on X: \"quote\" / X" → "Name: \"quote\""
 * - Trailing "/ X" or "| LinkedIn" etc (handled by cleanTitle, but the
 *   "on X:" pattern needs special handling here)
 */
function stripTitleNoise(title) {
  if (!title) return '';

  // 1. Strip leading notification count: "(2) Title" or "(99+) Title"
  title = title.replace(/^\(\d+\+?\)\s*/, '');

  // 1b. Strip inline counts like "Inbox (16,359)" or "Messages (42)"
  title = title.replace(/\s*\([\d,]+\+?\)\s*/g, ' ');

  // 2. Strip email addresses anywhere in the title (privacy + cleaner display)
  //    Catches patterns like "Subject - user@example.com - Gmail"
  //    First remove "- email@domain.com" segments (with separator)
  title = title.replace(/\s*[\-\u2010\u2011\u2012\u2013\u2014\u2015]\s*[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}/g, '');
  //    Then catch any remaining bare email addresses
  title = title.replace(/[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}/g, '');

  // 3. Clean up X/Twitter title format: "Name on X: \"quote text\"" → "Name: \"quote text\""
  title = title.replace(/\s+on X:\s*/, ': ');

  // 4. Strip trailing "/ X" (X/Twitter appends this)
  title = title.replace(/\s*\/\s*X\s*$/, '');

  return title.trim();
}

/**
 * cleanTitle(title, hostname)
 *
 * Strips redundant site name suffixes from tab titles.
 * Many sites append their name: "Article Title - Medium" or "Post | Reddit"
 * If the suffix matches the domain, we remove it for a cleaner look.
 */
function cleanTitle(title, hostname) {
  if (!title || !hostname) return title || '';

  const friendly = friendlyDomain(hostname);
  const domain = hostname.replace(/^www\./, '');

  // Common separator patterns at the end of titles
  // "Article Title - Site Name", "Article Title | Site Name", "Article Title — Site Name"
  const separators = [' - ', ' | ', ' — ', ' · ', ' – '];

  for (const sep of separators) {
    const idx = title.lastIndexOf(sep);
    if (idx === -1) continue;

    const suffix = title.slice(idx + sep.length).trim();
    const suffixLower = suffix.toLowerCase();

    // Check if the suffix matches the domain name, friendly name, or common variations
    if (
      suffixLower === domain.toLowerCase() ||
      suffixLower === friendly.toLowerCase() ||
      suffixLower === domain.replace(/\.\w+$/, '').toLowerCase() || // "github" from "github.com"
      domain.toLowerCase().includes(suffixLower) ||
      friendly.toLowerCase().includes(suffixLower)
    ) {
      const cleaned = title.slice(0, idx).trim();
      // Only strip if we're left with something meaningful (at least 5 chars)
      if (cleaned.length >= 5) return cleaned;
    }
  }

  return title;
}

/**
 * smartTitle(title, url)
 *
 * When the tab title is useless (just the URL, or a generic site name),
 * try to extract something meaningful from the URL itself.
 * Works for X/Twitter posts, GitHub repos, YouTube videos, Reddit threads, etc.
 */
function smartTitle(title, url) {
  if (!url) return title || '';

  let pathname = '';
  let hostname = '';
  try {
    const u = new URL(url);
    pathname = u.pathname;
    hostname = u.hostname;
  } catch {
    return title || '';
  }

  // Check if the title is basically just the URL (useless)
  const titleIsUrl = !title || title === url || title.startsWith(hostname) || title.startsWith('http');

  // X / Twitter — extract @username from /username/status/123456 URLs
  if ((hostname === 'x.com' || hostname === 'twitter.com' || hostname === 'www.x.com') && pathname.includes('/status/')) {
    const username = pathname.split('/')[1];
    if (username) {
      // If the title has actual content (not just URL), clean it and keep it
      if (!titleIsUrl) return title;
      return `Post by @${username}`;
    }
  }

  // GitHub — extract owner/repo or owner/repo/path context
  if (hostname === 'github.com' || hostname === 'www.github.com') {
    const parts = pathname.split('/').filter(Boolean);
    if (parts.length >= 2) {
      const owner = parts[0];
      const repo = parts[1];
      if (parts[2] === 'issues' && parts[3]) return `${owner}/${repo} Issue #${parts[3]}`;
      if (parts[2] === 'pull' && parts[3]) return `${owner}/${repo} PR #${parts[3]}`;
      if (parts[2] === 'blob' || parts[2] === 'tree') return `${owner}/${repo} — ${parts.slice(4).join('/')}`;
      if (titleIsUrl) return `${owner}/${repo}`;
    }
  }

  // YouTube — if title is just a URL, at least say "YouTube Video"
  if ((hostname === 'www.youtube.com' || hostname === 'youtube.com') && pathname === '/watch') {
    if (titleIsUrl) return 'YouTube Video';
  }

  // Reddit — extract subreddit and post hint from URL
  if ((hostname === 'www.reddit.com' || hostname === 'reddit.com' || hostname === 'old.reddit.com') && pathname.includes('/comments/')) {
    const parts = pathname.split('/').filter(Boolean);
    const subIdx = parts.indexOf('r');
    if (subIdx !== -1 && parts[subIdx + 1]) {
      const sub = parts[subIdx + 1];
      if (titleIsUrl) return `r/${sub} post`;
    }
  }

  return title || url;
}


/* ----------------------------------------------------------------
   AI TITLE REWRITER — Groq-backed cleanup for tab + article titles.
   Results are cached by URL in chrome.storage.local; uncached items
   are batched and sent to Groq, then the dashboard re-renders.
   ---------------------------------------------------------------- */

const AI_CACHE_KEY     = 'ai_titles';
const AI_KEY_STORAGE   = 'groq_api_key';
const AI_MODEL         = 'openai/gpt-oss-20b';
const AI_BATCH_SIZE    = 15;
const AI_MAX_INPUT_LEN = 200;

let aiTitleCache = {};
let aiApiKey     = '';
let aiInflight   = new Set(); // URLs currently being rewritten
let aiPending    = false;     // re-render coalescer

async function loadAiState() {
  const data = await chrome.storage.local.get([AI_CACHE_KEY, AI_KEY_STORAGE]);
  aiTitleCache = data[AI_CACHE_KEY] || {};
  aiApiKey     = data[AI_KEY_STORAGE] || '';
}

function aiTitleFor(url, fallback) {
  return (url && aiTitleCache[url]) || fallback;
}

function aiSystemPrompt() {
  return 'You rewrite browser tab and RSS article titles to be cleaner and shorter. Rules: strip site names ("— YouTube", "| GitHub"), notification counts ("(3)"), emoji prefixes, and marketing fluff. Keep the meaningful content. Max 60 chars. Preserve language. Respond with a JSON object: {"items":[{"id":number,"title":string}]} matching the input ids exactly. No prose.';
}

async function aiCallGroq(batch) {
  // batch: [{ id, title }]
  if (!aiApiKey) return {};
  const userMsg = `Rewrite these titles. Return JSON {"items":[{"id":..,"title":..}]} only.\n\n${JSON.stringify(batch)}`;
  const res = await fetch('https://api.groq.com/openai/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${aiApiKey}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      model: AI_MODEL,
      messages: [
        { role: 'system', content: aiSystemPrompt() },
        { role: 'user', content: userMsg },
      ],
      response_format: { type: 'json_object' },
      temperature: 0.2,
      max_tokens: 800,
    }),
  });
  if (!res.ok) throw new Error(`Groq ${res.status}: ${await res.text()}`);
  const data = await res.json();
  const content = data.choices?.[0]?.message?.content;
  if (!content) return {};
  let parsed;
  try { parsed = JSON.parse(content); } catch { return {}; }
  const arr = Array.isArray(parsed) ? parsed : (parsed.items || parsed.titles || parsed.results || []);
  const byId = {};
  for (const item of arr) {
    if (typeof item?.id === 'number' && typeof item?.title === 'string') {
      byId[item.id] = item.title.trim();
    }
  }
  return byId;
}

async function enqueueAiRewrites(items) {
  // items: [{ url, title }]
  if (!aiApiKey || !items?.length) return;

  const todo = [];
  for (const it of items) {
    if (!it?.url || !it?.title) continue;
    if (aiTitleCache[it.url]) continue;
    if (aiInflight.has(it.url)) continue;
    const clean = it.title.slice(0, AI_MAX_INPUT_LEN);
    todo.push({ url: it.url, title: clean });
    aiInflight.add(it.url);
  }
  if (todo.length === 0) return;

  let anyUpdated = false;
  for (let i = 0; i < todo.length; i += AI_BATCH_SIZE) {
    const chunk = todo.slice(i, i + AI_BATCH_SIZE);
    const batch = chunk.map((it, idx) => ({ id: idx, title: it.title }));
    try {
      const result = await aiCallGroq(batch);
      for (let j = 0; j < chunk.length; j++) {
        const rewritten = result[j];
        const url = chunk[j].url;
        aiInflight.delete(url);
        if (rewritten && rewritten.length > 1 && rewritten.length <= 80) {
          aiTitleCache[url] = rewritten;
          anyUpdated = true;
        }
      }
    } catch (err) {
      console.warn('[swoosh] AI rewrite failed:', err.message);
      for (const it of chunk) aiInflight.delete(it.url);
      break;
    }
  }

  if (anyUpdated) {
    await chrome.storage.local.set({ [AI_CACHE_KEY]: aiTitleCache });
    if (!aiPending) {
      aiPending = true;
      setTimeout(() => { aiPending = false; renderDashboard(); }, 50);
    }
  }
}

async function aiClearCache() {
  aiTitleCache = {};
  await chrome.storage.local.remove(AI_CACHE_KEY);
}


/* ----------------------------------------------------------------
   SMART TAB GROUPING — Groq clusters tabs by intent/topic across
   domains. Result is cached by tab-set signature (sorted URL hash).
   ---------------------------------------------------------------- */

const SMART_GROUP_CACHE_KEY = 'smart_groups_cache';
const GROUPING_MODE_KEY     = 'grouping_mode';
const SMART_MIN_TABS        = 5;
const SMART_MAX_TABS        = 50;
const SMART_GROUP_MODEL     = 'llama-3.3-70b-versatile';
// Bump this whenever the prompt or post-processing changes — invalidates cached groupings.
const SMART_PROMPT_VERSION  = 'v4';

let groupingMode     = 'domain';   // 'domain' | 'smart'
let smartGroupCache  = {};         // signature -> { groups: [{name, urls}] }
let smartInflight    = null;       // current signature being fetched

async function loadGroupingState() {
  const data = await chrome.storage.local.get([GROUPING_MODE_KEY, SMART_GROUP_CACHE_KEY]);
  groupingMode    = data[GROUPING_MODE_KEY] === 'smart' ? 'smart' : 'domain';
  smartGroupCache = data[SMART_GROUP_CACHE_KEY] || {};
}

function tabSetSignature(tabs) {
  // Deterministic hash of sorted URLs — same set of tabs → same signature.
  const urls = tabs.map(t => t.url || '').sort();
  let h = 0;
  for (const u of urls) {
    for (let i = 0; i < u.length; i++) {
      h = ((h << 5) - h + u.charCodeAt(i)) | 0;
    }
    h = (h * 31) | 0;
  }
  return SMART_PROMPT_VERSION + ':' + urls.length + ':' + h.toString(36);
}

function smartGroupSystemPrompt() {
  return [
    'You are an expert at clustering browser tabs by the user\'s underlying activity, project, or topic — NOT by domain.',
    '',
    'PROCESS:',
    '1. Read every tab title carefully. Infer what the user is doing, learning, building, or researching.',
    '2. Find clusters of 2+ tabs that share an intent — even when domains differ. A GitHub repo about LLMs + a YouTube tutorial about LLMs + a Claude docs page = one cluster ("LLM development"). A YouTube vlog about Tokyo + a Google Maps tab of Shibuya + a Booking.com hotel = one cluster ("Tokyo trip").',
    '3. Be generous with cluster count. It is BETTER to create 10 specific clusters than 6 clusters with a giant grab-bag at the end. Even a cluster of just 2 related tabs is valuable.',
    '',
    'NAMING:',
    '- 2-5 words, descriptive of the activity. Examples: "Claude & AI tooling", "YouTube watch later", "React state debugging", "Job search outreach".',
    '- ABSOLUTELY FORBIDDEN names: "Other", "Misc", "Various", "General", "Unrelated", "Miscellaneous", "Random", "Mixed", "Reading queue", "Reading list", "Browser tabs", "Saved for later". These signal lazy clustering. If tabs feel unrelated, look for a TOPICAL thread — "AI tooling articles", "JS framework reading", "Cooking recipes", "Hiring resources" — name the SUBJECT, not the activity of reading.',
    '- If you create 2 GitHub repos cluster: name it by what they share ("AI agent repos", "Open-source tools") — never "GitHub stuff".',
    '',
    'COVERAGE (CRITICAL):',
    '- Every single tab id from the input must appear in exactly one group in your output. No duplicates, no omissions.',
    '- Before finalizing, mentally count: input had N tabs; your output must reference all N ids. Missing ids is the #1 failure mode — do not skip any.',
    '- If a tab truly fits nowhere, create a small 1-2 tab group named after its actual content ("Redis intro video", "Personal philosophy"). NEVER silently drop it.',
    '- Create 5-12 groups. Err on the side of MORE specific groups, not fewer. A 2-tab cluster with a real theme beats lumping those 2 into "Other".',
    '- HARD LIMIT: no single group may contain more than 40% of the tabs. If you find yourself wanting to, that group is too broad — split it by topic.',
    '- ANTI-PATTERN to avoid: after making 5-6 good clusters, dumping the remaining 8-10 tabs into one giant "Other", "Miscellaneous", or "Reading queue". If you see yourself doing this, STOP and break the dump into 2-4 smaller, more specific clusters instead.',
    '',
    'OUTPUT FORMAT (strict JSON, no prose):',
    '{"groups":[{"name":"...","ids":[0,3,5]},{"name":"...","ids":[1,2,4]}]}',
  ].join('\n');
}

async function smartGroupCallGroq(tabsForLLM, { allowRetry = true } = {}) {
  if (!aiApiKey) throw new Error('no api key');
  const payload = tabsForLLM.map(t => ({ id: t.id, host: t.host, title: t.title }));
  const userMsg = `Group these ${payload.length} tabs:\n${JSON.stringify(payload)}`;

  const res = await fetch('https://api.groq.com/openai/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${aiApiKey}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      model: SMART_GROUP_MODEL,
      messages: [
        { role: 'system', content: smartGroupSystemPrompt() },
        { role: 'user',   content: userMsg },
      ],
      response_format: { type: 'json_object' },
      temperature: 0.2,
      max_tokens: 2000,
    }),
  });

  if (res.status === 429 && allowRetry) {
    const body = await res.text();
    // Groq encodes the wait as "try again in 19.405s" in the message; the
    // retry-after header is also set on most responses.
    const headerWait = parseFloat(res.headers.get('retry-after') || '');
    const bodyMatch  = body.match(/try again in\s+([\d.]+)\s*s/i);
    const waitSec    = Number.isFinite(headerWait) && headerWait > 0
      ? headerWait
      : (bodyMatch ? parseFloat(bodyMatch[1]) : 20);
    const waitMs     = Math.min(Math.ceil(waitSec * 1000) + 500, 30000);
    console.warn(`[swoosh] Groq 429 — waiting ${waitMs}ms then retrying`);
    await new Promise(r => setTimeout(r, waitMs));
    return smartGroupCallGroq(tabsForLLM, { allowRetry: false });
  }

  if (!res.ok) throw new Error(`Groq ${res.status}: ${await res.text()}`);
  const data = await res.json();
  const content = data.choices?.[0]?.message?.content;
  if (!content) throw new Error('empty response');
  console.log('[swoosh] smart grouping raw response:', content);
  return JSON.parse(content);
}

function validateAndMapGroups(rawResult, tabs) {
  // rawResult: { groups: [{name, ids}] }
  // tabs: original array with { id, url, ... }
  const idToTab = new Map(tabs.map(t => [t.id, t]));
  const claimed = new Set();
  const out = [];

  const groups = Array.isArray(rawResult?.groups) ? rawResult.groups : [];
  for (const g of groups) {
    if (!g || typeof g.name !== 'string' || !Array.isArray(g.ids)) continue;
    const groupTabs = [];
    for (const id of g.ids) {
      if (claimed.has(id)) continue;
      const tab = idToTab.get(id);
      if (!tab) continue;
      claimed.add(id);
      groupTabs.push(tab);
    }
    if (groupTabs.length === 0) continue;
    out.push({ name: g.name.trim().slice(0, 60), tabs: groupTabs });
  }
  return out;
}

async function smartGroupTabs(tabs) {
  // tabs: array of chrome.tabs with { id, url, title, favIconUrl, ... }
  if (!aiApiKey || groupingMode !== 'smart') return null;
  if (tabs.length < SMART_MIN_TABS) return null;

  const signature = tabSetSignature(tabs);
  const cached = smartGroupCache[signature];
  if (cached) {
    return rebuildGroupsFromCache(cached, tabs);
  }
  if (smartInflight === signature) return null; // already fetching this exact set

  // Dedupe by URL — send only unique URLs to the LLM. After clustering,
  // expand each representative back to ALL tabs sharing its URL so that
  // duplicate-tab detection works inside the resulting card.
  const urlToAll = new Map();
  for (const t of tabs) {
    if (!t.url) continue;
    if (!urlToAll.has(t.url)) urlToAll.set(t.url, []);
    urlToAll.get(t.url).push(t);
  }
  const uniqueReps = [...urlToAll.values()].map(arr => arr[0]);

  const slice = uniqueReps.slice(0, SMART_MAX_TABS);
  const tabsForLLM = slice.map((t, idx) => {
    let host = '';
    try { host = new URL(t.url).hostname; } catch {}
    return {
      id: idx,
      host,
      title: (t.title || '').slice(0, 120), // generous — quality matters
      __ref: t,
    };
  });

  smartInflight = signature;
  let rawResult;
  try {
    rawResult = await smartGroupCallGroq(tabsForLLM);
  } catch (err) {
    console.warn('[swoosh] smart grouping failed:', err.message);
    smartInflight = null;
    return null;
  }
  smartInflight = null;

  // The LLM returned synthetic ids (0..N). Build proxy objects whose `id`
  // matches the synthetic ids, then unwrap back to the real chrome tabs.
  const proxies = tabsForLLM.map(t => ({ ...t.__ref, id: t.id, __ref: t.__ref }));
  const mappedProxies = validateAndMapGroups(rawResult, proxies);

  // Expand each representative back to all tabs sharing its URL so that
  // duplicates land in the same card and the within-card dedup detection works.
  const mapped = mappedProxies.map(g => ({
    name: g.name,
    tabs: g.tabs.flatMap(t => urlToAll.get(t.__ref.url) || [t.__ref]),
  }));

  // Final safety net — if any URLs are still unaccounted for (rare), drop them
  // into a thoughtfully-named bucket rather than calling it "Other".
  const claimedUrls = new Set();
  for (const g of mapped) for (const t of g.tabs) claimedUrls.add(t.url);
  const stillOrphan = tabs.filter(t => t.url && !claimedUrls.has(t.url));
  if (stillOrphan.length > 0) {
    console.warn(`[swoosh] safety net: ${stillOrphan.length}/${tabs.length} tabs unclaimed by LLM, salvaging by domain`);
    const salvaged = salvageOrphansByDomain(stillOrphan);
    mapped.push(...salvaged);
  }

  // Persist cache as { name, urls } so it survives reloads even if tab IDs change
  smartGroupCache[signature] = {
    groups: mapped.map(g => ({ name: g.name, urls: g.tabs.map(t => t.url) })),
    generatedAt: Date.now(),
  };
  // Cap cache to ~30 entries
  const keys = Object.keys(smartGroupCache);
  if (keys.length > 30) {
    const sorted = keys.sort((a, b) => (smartGroupCache[a].generatedAt || 0) - (smartGroupCache[b].generatedAt || 0));
    for (const k of sorted.slice(0, keys.length - 30)) delete smartGroupCache[k];
  }
  await chrome.storage.local.set({ [SMART_GROUP_CACHE_KEY]: smartGroupCache });

  return mapped;
}

function rebuildGroupsFromCache(cached, tabs) {
  // cached.groups: [{name, urls}], tabs: live tab list
  // Map url → ALL tabs with that url, so dupes follow their group.
  const urlToAll = new Map();
  for (const t of tabs) {
    if (!t.url) continue;
    if (!urlToAll.has(t.url)) urlToAll.set(t.url, []);
    urlToAll.get(t.url).push(t);
  }
  const claimedUrls = new Set();
  const out = [];
  for (const g of cached.groups) {
    const groupTabs = [];
    for (const url of g.urls) {
      if (claimedUrls.has(url)) continue;
      const matches = urlToAll.get(url);
      if (matches && matches.length > 0) {
        claimedUrls.add(url);
        groupTabs.push(...matches);
      }
    }
    if (groupTabs.length > 0) out.push({ name: g.name, tabs: groupTabs });
  }
  const orphans = tabs.filter(t => t.url && !claimedUrls.has(t.url));
  if (orphans.length > 0) {
    out.push(...salvageOrphansByDomain(orphans));
  }
  return out;
}

// Local-only fallback when the LLM drops tabs. Group by host: any host with
// 2+ tabs becomes its own friendly-named group; singletons collapse into a
// single "Unclustered" bucket (which the user can see is genuinely a remainder).
function salvageOrphansByDomain(orphans) {
  const byHost = new Map();
  const singletons = [];
  const hostOf = (t) => { try { return new URL(t.url).hostname; } catch { return ''; } };

  // First pass: bucket by host
  const tmp = new Map();
  for (const t of orphans) {
    const h = hostOf(t);
    if (!h) { singletons.push(t); continue; }
    if (!tmp.has(h)) tmp.set(h, []);
    tmp.get(h).push(t);
  }
  // Promote 2+ buckets to real groups; drop 1-tab hosts into singletons
  for (const [host, ts] of tmp) {
    if (ts.length >= 2) byHost.set(host, ts);
    else singletons.push(...ts);
  }

  const out = [];
  for (const [host, ts] of byHost) {
    out.push({ name: friendlyDomain(host) || host, tabs: ts });
  }
  if (singletons.length > 0) {
    out.push({ name: 'Unclustered', tabs: singletons });
  }
  return out;
}


const ICONS = {
  // Tab/browser icon — used in the "N tabs open" badge
  tabs: `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M3 8.25V18a2.25 2.25 0 0 0 2.25 2.25h13.5A2.25 2.25 0 0 0 21 18V8.25m-18 0V6a2.25 2.25 0 0 1 2.25-2.25h13.5A2.25 2.25 0 0 1 21 6v2.25m-18 0h18" /></svg>`,

  // X / close icon — used in "Close N tabs" button
  close: `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M6 18 18 6M6 6l12 12" /></svg>`,

  // Archive / trash icon — used in "Close & archive" button
  archive: `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M20.25 7.5l-.625 10.632a2.25 2.25 0 0 1-2.247 2.118H6.622a2.25 2.25 0 0 1-2.247-2.118L3.75 7.5m6 4.125l2.25 2.25m0 0l2.25 2.25M12 13.875l2.25-2.25M12 13.875l-2.25 2.25M3.375 7.5h17.25c.621 0 1.125-.504 1.125-1.125v-1.5c0-.621-.504-1.125-1.125-1.125H3.375c-.621 0-1.125.504-1.125 1.125v1.5c0 .621.504 1.125 1.125 1.125Z" /></svg>`,

  // Arrow up-right — used in "Focus on this" button
  focus: `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="m4.5 19.5 15-15m0 0H8.25m11.25 0v11.25" /></svg>`,

  pin: `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M15.75 5.25v3.75m0 0H18a2.25 2.25 0 0 1 0 4.5h-1.5m-2.25-8.25H8.25m7.5 0v-1.5A1.5 1.5 0 0 0 14.25 2.25h-4.5A1.5 1.5 0 0 0 8.25 3.75v1.5m0 0v3.75m0 0H6a2.25 2.25 0 0 0 0 4.5h2.25m3.75 0v7.5m0-7.5h-3.75m3.75 0h3.75" /></svg>`
};


/* ----------------------------------------------------------------
   DOMAIN CATEGORY COLOR-CODING
   Maps hostname patterns to categories for the colored top bar on cards.
   ---------------------------------------------------------------- */
const DOMAIN_CATEGORIES = {
  work: [
    'docs.google.com', 'drive.google.com', 'sheets.google.com', 'slides.google.com',
    'notion.so', 'slack.com', 'teams.microsoft.com', 'office.com',
    'sharepoint.com', 'outlook.office.com', 'outlook.live.com',
    'calendar.google.com', 'mail.google.com', 'meet.google.com',
    'zoom.us', 'webex.com', 'whereby.com',
    'trello.com', 'asana.com', 'monday.com', 'linear.app', 'clickup.com',
    'airtable.com', 'figma.com', 'miro.com', 'loom.com',
    'dropbox.com', 'box.com', '1password.com', 'lastpass.com',
  ],
  work_partial: ['jira', 'confluence', 'azure', 'atlassian', 'sharepoint', 'zendesk', 'hubspot', 'salesforce'],
  social: [
    'twitter.com', 'x.com', 'linkedin.com', 'facebook.com',
    'reddit.com', 'instagram.com', 'threads.net',
    'tiktok.com', 'snapchat.com', 'pinterest.com', 'tumblr.com',
    'discord.com', 'telegram.org', 'whatsapp.com', 'messenger.com',
    'mastodon.social', 'bsky.app',
  ],
  dev: [
    'github.com', 'gitlab.com', 'bitbucket.org', 'stackoverflow.com',
    'npmjs.com', 'pypi.org', 'crates.io', 'pkg.go.dev',
    'localhost', 'codepen.io', 'codesandbox.io', 'stackblitz.com', 'replit.com',
    'vercel.com', 'netlify.com', 'render.com', 'railway.app', 'fly.io',
    'developer.mozilla.org', 'devdocs.io', 'css-tricks.com',
    'aws.amazon.com', 'console.cloud.google.com', 'portal.azure.com',
    'postman.com', 'insomnia.rest',
  ],
  media: [
    'youtube.com', 'netflix.com', 'spotify.com', 'twitch.tv',
    'music.youtube.com', 'podcasts.apple.com',
    'hulu.com', 'disneyplus.com', 'primevideo.com', 'max.com', 'peacocktv.com',
    'soundcloud.com', 'deezer.com', 'tidal.com',
    'vimeo.com', 'dailymotion.com',
    'news.ycombinator.com', 'medium.com', 'substack.com', 'dev.to',
  ],
  ai: [
    'chatgpt.com', 'chat.openai.com', 'openai.com',
    'claude.ai', 'anthropic.com',
    'gemini.google.com', 'bard.google.com', 'aistudio.google.com',
    'perplexity.ai',
    'copilot.microsoft.com', 'bing.com',
    'mistral.ai', 'chat.mistral.ai',
    'huggingface.co', 'replicate.com',
    'poe.com', 'you.com', 'phind.com',
    'grok.com', 'x.ai',
    'character.ai', 'pi.ai',
  ],
};

function getDomainCategory(domain) {
  if (!domain || domain.startsWith('__')) return 'default';
  const d = domain.toLowerCase().replace(/^www\./, '');
  for (const [cat, hosts] of Object.entries(DOMAIN_CATEGORIES)) {
    if (cat.endsWith('_partial')) {
      const baseCat = cat.replace('_partial', '');
      if (hosts.some(h => d.includes(h))) return baseCat;
    } else {
      if (hosts.includes(d)) return cat;
    }
  }
  return 'default';
}

/* ----------------------------------------------------------------
   IN-MEMORY STORE FOR OPEN-TAB GROUPS

   domainGroups is populated by renderStaticDashboard().
   ---------------------------------------------------------------- */
let domainGroups    = [];

const STALE_DEFAULT_HOURS = 4;
let staleThresholdHours = STALE_DEFAULT_HOURS;
let STALE_THRESHOLD_MS = staleThresholdHours * 60 * 60 * 1000;
let currentStaleTabs = [];


/* ----------------------------------------------------------------
   HELPER: filter out browser-internal pages
   We call this in multiple places, so it lives in one spot.
   ---------------------------------------------------------------- */

/**
 * getRealTabs()
 *
 * Returns all open tabs that are real web pages — no chrome://, extension
 * pages, about:blank, etc. We only want to show and manage actual websites.
 */
function getRealTabs() {
  return openTabs.filter(t => {
    const url = t.url || '';
    if (url.startsWith('chrome://extensions') || url.startsWith('edge://extensions')) return true;
    return (
      !url.startsWith('chrome://') &&
      !url.startsWith('chrome-extension://') &&
      !url.startsWith('about:') &&
      !url.startsWith('edge://') &&
      !url.startsWith('brave://')
    );
  });
}

/**
 * checkSwooshDupes()
 *
 * Counts how many Swoosh new-tab pages are open. If more than 1,
 * shows a banner offering to close the extras.
 */
function checkSwooshDupes() {
  const swooshTabs = openTabs.filter(t =>
    t.url === 'chrome://newtab/' || t.url === 'edge://newtab/' || t.url === 'about:newtab'
  );
  if (swooshTabs.length > 1) {
    (async () => {
      const all = await chrome.tabs.query({});
      const newTabUrls = ['chrome://newtab/', 'edge://newtab/', 'about:newtab'];
      const current = await chrome.tabs.getCurrent();
      const toClose = all.filter(t => t.id !== current?.id && newTabUrls.includes(t.url)).map(t => t.id);
      if (toClose.length > 0) await chrome.tabs.remove(toClose);
    })();
  }
}


/* ----------------------------------------------------------------
   DOMAIN CARD RENDERER (for static default view)

   Groups open tabs by domain (e.g. all github.com tabs together)
   and renders a card per domain.
   ---------------------------------------------------------------- */

/**
 * buildOverflowChips(hiddenTabs, urlCounts)
 *
 * Builds the expandable "+N more" section for tab lists that exceed 8 items.
 * Returns HTML string with hidden chips and a clickable expand button.
 * Used by domain cards when there are more than 8 tabs.
 */
function buildOverflowChips(hiddenTabs, urlCounts = {}) {
  const hiddenChips = hiddenTabs.map(tab => {
    const baseLabel = cleanTitle(smartTitle(stripTitleNoise(tab.title || ''), tab.url), '');
    const label   = aiTitleFor(tab.url, baseLabel);
    const count   = urlCounts[tab.url] || 1;
    const dupeTag = count > 1 ? ` <span class="chip-dupe-badge">(${count}x)</span>` : '';
    const chipClass = (count > 1 ? ' chip-has-dupes' : '') + (tab.pinned ? ' chip-pinned' : '');
    const safeUrl = (tab.url || '').replace(/"/g, '&quot;');
    const safeTitle = label.replace(/"/g, '&quot;');
    const fUrl = faviconUrl(tab.url, 16);
    const pinTag = tab.pinned ? `<span class="chip-pin-icon">${ICONS.pin}</span>` : '';
    return `<div class="page-chip clickable${chipClass}" data-action="focus-tab" data-tab-url="${safeUrl}" data-tooltip="${safeTitle}">
      ${pinTag}${fUrl ? `<img class="chip-favicon favicon-img" src="${fUrl}" alt="">` : ''}
      <span class="chip-text">${escHtml(label)}</span>${dupeTag}
      <div class="chip-actions">
        <button class="chip-action chip-save" data-action="defer-single-tab" data-tab-url="${safeUrl}" data-tab-title="${safeTitle}" data-tooltip="Save for later">
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M17.593 3.322c1.1.128 1.907 1.077 1.907 2.185V21L12 17.25 4.5 21V5.507c0-1.108.806-2.057 1.907-2.185a48.507 48.507 0 0 1 11.186 0Z" /></svg>
        </button>
        <button class="chip-action chip-close" data-action="close-single-tab" data-tab-url="${safeUrl}" data-tooltip="Close tab">
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M6 18 18 6M6 6l12 12" /></svg>
        </button>
      </div>
    </div>`;
  }).join('');

  return `
    <div class="page-chips-overflow" style="display:none">${hiddenChips}</div>
    <div class="page-chip page-chip-overflow clickable" data-action="expand-chips">
      <span class="chip-text">+${hiddenTabs.length} more</span>
    </div>`;
}

/**
 * renderDomainCard(group, groupIndex)
 *
 * Builds the HTML for one domain group card in the static view.
 * "group" is: { domain, tabs: [{ url, title, tabId }] }
 *
 * Visually similar to renderOpenTabsMissionCard() but with a neutral
 * gray status bar (amber if duplicates exist).
 */
function renderDomainCard(group) {
  const tabs      = group.tabs || [];
  const tabCount  = tabs.length;
  const isLanding = group.domain === '__landing-pages__';
  const isSmart   = !!group.isSmart;
  const stableId  = 'domain-' + (group.domain || group.displayName || 'group').replace(/[^a-z0-9]/g, '-');

  // Detect duplicates within this domain group (exact URL match)
  const urlCounts = {};
  for (const tab of tabs) {
    urlCounts[tab.url] = (urlCounts[tab.url] || 0) + 1;
  }
  const dupeUrls = Object.entries(urlCounts).filter(([, c]) => c > 1);
  const hasDupes = dupeUrls.length > 0;
  const totalExtras = dupeUrls.reduce((s, [, c]) => s + c - 1, 0);

  // Site favicon + name
  let cardName;
  if (isSmart) cardName = group.displayName || group.domain;
  else if (isLanding) cardName = 'Homepages';
  else cardName = friendlyDomain(group.domain);

  // For smart groups, prefer the favicon of the most-represented domain.
  let firstFavicon = '';
  if (isSmart) {
    const hostCount = {};
    for (const t of tabs) {
      let h = '';
      try { h = new URL(t.url).hostname; } catch { continue; }
      hostCount[h] = (hostCount[h] || 0) + 1;
    }
    const topHost = Object.entries(hostCount).sort((a, b) => b[1] - a[1])[0]?.[0];
    const topTab = tabs.find(t => { try { return new URL(t.url).hostname === topHost; } catch { return false; } });
    firstFavicon = topTab ? faviconUrl(topTab.url, 16) : faviconUrl(tabs[0]?.url, 16);
  } else {
    firstFavicon = faviconUrl(tabs[0]?.url, 16);
  }
  const faviconEl = firstFavicon
    ? `<img class="card-favicon favicon-img" src="${firstFavicon}" alt="" aria-hidden="true">`
    : `<span class="card-favicon card-favicon-fallback" aria-hidden="true">${(cardName || '?')[0].toUpperCase()}</span>`;

  // Minimal tab count — only shown for 2+
  const countEl = tabCount > 1
    ? `<span class="card-tab-count">${tabCount}</span>`
    : '';

  // Deduplicate for display: show each URL once with (Nx) badge if duplicated
  const seen = new Set();
  const uniqueTabs = [];
  for (const tab of tabs) {
    if (!seen.has(tab.url)) {
      seen.add(tab.url);
      uniqueTabs.push(tab);
    }
  }
  const visibleTabs = uniqueTabs.slice(0, 8);
  const extraCount  = uniqueTabs.length - visibleTabs.length;
  const pageChips = visibleTabs.map(tab => {
    const baseLabel = cleanTitle(smartTitle(stripTitleNoise(tab.title || ''), tab.url), group.domain);
    let label = aiTitleFor(tab.url, baseLabel);
    // For localhost tabs, prepend the port number so you can tell projects apart
    try {
      const parsed = new URL(tab.url);
      if (parsed.hostname === 'localhost' && parsed.port) {
        label = `${parsed.port} ${label}`;
      }
    } catch {}
    const count   = urlCounts[tab.url];
    const dupeTag = count > 1
      ? ` <span class="chip-dupe-badge">(${count}x)</span>`
      : '';
    const chipClass = (count > 1 ? ' chip-has-dupes' : '') + (tab.pinned ? ' chip-pinned' : '');
    const safeUrl = (tab.url || '').replace(/"/g, '&quot;');
    const safeTitle = label.replace(/"/g, '&quot;');
    const fUrl = faviconUrl(tab.url, 16);
    const pinTag = tab.pinned ? `<span class="chip-pin-icon">${ICONS.pin}</span>` : '';
    return `<div class="page-chip clickable${chipClass}" data-action="focus-tab" data-tab-url="${safeUrl}" data-tooltip="${safeTitle}">
      ${pinTag}${fUrl ? `<img class="chip-favicon favicon-img" src="${fUrl}" alt="">` : ''}
      <span class="chip-text">${escHtml(label)}</span>${dupeTag}
      <div class="chip-actions">
        <button class="chip-action chip-save" data-action="defer-single-tab" data-tab-url="${safeUrl}" data-tab-title="${safeTitle}" data-tooltip="Save for later">
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M17.593 3.322c1.1.128 1.907 1.077 1.907 2.185V21L12 17.25 4.5 21V5.507c0-1.108.806-2.057 1.907-2.185a48.507 48.507 0 0 1 11.186 0Z" /></svg>
        </button>
        <button class="chip-action chip-close" data-action="close-single-tab" data-tab-url="${safeUrl}" data-tooltip="Close tab">
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M6 18 18 6M6 6l12 12" /></svg>
        </button>
      </div>
    </div>`;
  }).join('') + (extraCount > 0 ? buildOverflowChips(uniqueTabs.slice(8), urlCounts) : '');

  let dupeIcon = '';
  if (hasDupes) {
    const dupeUrlsEncoded = dupeUrls.map(([url]) => encodeURIComponent(url)).join(',');
    dupeIcon = `
      <button class="card-dupe-icon" data-action="dedup-keep-one" data-dupe-urls="${dupeUrlsEncoded}" data-tooltip="Close ${totalExtras} duplicate${totalExtras !== 1 ? 's' : ''}">
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M15.75 17.25v3.375c0 .621-.504 1.125-1.125 1.125h-9.75a1.125 1.125 0 0 1-1.125-1.125V7.875c0-.621.504-1.125 1.125-1.125H6.75a9.06 9.06 0 0 1 1.5.124m7.5 10.376h3.375c.621 0 1.125-.504 1.125-1.125V11.25c0-4.46-3.243-8.161-7.5-8.876a9.06 9.06 0 0 0-1.5-.124H9.375c-.621 0-1.125.504-1.125 1.125v3.5m7.5 10.375H9.375a1.125 1.125 0 0 1-1.125-1.125v-9.25m12 6.625v-1.875a3.375 3.375 0 0 0-3.375-3.375h-1.5a1.125 1.125 0 0 1-1.125-1.125v-1.5a3.375 3.375 0 0 0-3.375-3.375H9.75" /></svg>
      </button>`;
  }

  const cardClass = hasDupes ? 'has-amber-bar' : 'has-neutral-bar';

  return `
    <div class="mission-card domain-card is-expanded ${cardClass}" data-domain-id="${stableId}">
      <div class="mission-content">
        <div class="mission-top">
          ${faviconEl}
          <span class="mission-name">${cardName}</span>
          ${countEl}
          <div class="card-top-actions">
            ${dupeIcon}
            <button class="card-close-btn" data-action="close-domain-tabs" data-domain-id="${stableId}" data-tooltip="Close all ${tabCount} tab${tabCount !== 1 ? 's' : ''}">
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M6 18 18 6M6 6l12 12" /></svg>
            </button>
            <button class="card-expand-btn" data-tooltip="Toggle tabs">
              <svg class="expand-chevron" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="m19.5 8.25-7.5 7.5-7.5-7.5" /></svg>
            </button>
          </div>
        </div>
        <div class="mission-pages collapsed-chips">${pageChips}</div>
      </div>
    </div>`;
}


/* ----------------------------------------------------------------
   DEFERRED TABS — "Saved for Later" checklist column

   Fetches deferred tabs from the server and renders:
   1. Active items as a checklist (checkbox + title + dismiss)
   2. Archived items in a collapsible section with search
   ---------------------------------------------------------------- */

/**
 * renderDeferredColumn()
 *
 * Fetches all deferred tabs (active + archived) from the API and
 * renders them into the right-side column. Called on every dashboard
 * load.
 */
async function renderDeferredColumn() {
  const column    = document.getElementById('deferredColumn');
  const list      = document.getElementById('deferredList');
  const empty     = document.getElementById('deferredEmpty');
  const countEl   = document.getElementById('deferredCount');
  const archiveEl = document.getElementById('deferredArchive');
  const archiveCountEl = document.getElementById('archiveCount');
  const archiveList    = document.getElementById('archiveList');

  if (!column) return;

  try {
    const data = await getDeferred();

    const active   = data.active || [];
    const archived = data.archived || [];

    if (active.length === 0) {
      if (column.style.display !== 'none') {
        column.classList.add('hiding');
        column.addEventListener('transitionend', function handler(evt) {
          if (evt.target !== column) return;
          column.removeEventListener('transitionend', handler);
          column.style.display = 'none';
          column.classList.remove('hiding');
        });
        setTimeout(() => {
          if (column.classList.contains('hiding')) {
            column.style.display = 'none';
            column.classList.remove('hiding');
          }
        }, 500);
      }
      return;
    }

    const wasHidden = column.style.display === 'none';
    column.classList.remove('hiding');
    if (wasHidden) {
      column.style.width = '0';
      column.style.opacity = '0';
      column.style.transform = 'translateY(8px)';
      column.style.display = 'block';
      void column.offsetWidth;
      column.style.width = '';
      column.style.opacity = '';
      column.style.transform = '';
    } else {
      column.style.display = 'block';
    }

    if (countEl) countEl.textContent = `${active.length} item${active.length !== 1 ? 's' : ''}`;
    list.innerHTML = active.map(item => renderDeferredItem(item)).join('');
    list.style.display = 'block';
    empty.style.display = 'none';

    // Render archive section
    if (archived.length > 0) {
      archiveCountEl.textContent = `(${archived.length})`;
      archiveList.innerHTML = archived.map(item => renderArchiveItem(item)).join('');
      archiveEl.style.display = 'block';
    } else {
      archiveEl.style.display = 'none';
    }

  } catch (err) {
    console.warn('[swoosh] Could not load deferred tabs:', err);
    if (column.style.display !== 'none') {
      column.classList.add('hiding');
      column.addEventListener('transitionend', function handler(evt) {
        if (evt.target !== column) return;
        column.removeEventListener('transitionend', handler);
        column.style.display = 'none';
        column.classList.remove('hiding');
      });
      setTimeout(() => {
        if (column.classList.contains('hiding')) {
          column.style.display = 'none';
          column.classList.remove('hiding');
        }
      }, 500);
    }
  }
}

/**
 * renderDeferredItem(item)
 *
 * Builds the HTML for a single checklist item in the Saved for Later column.
 * Each item has: checkbox, title (clickable link), domain, time ago, dismiss X.
 */
function renderDeferredItem(item) {
  let domain = '';
  try { domain = new URL(item.url).hostname.replace(/^www\./, ''); } catch {}
  const faviconSrc = item.favicon_url || faviconUrl(item.url, 16);
  const ago = timeAgo(item.deferred_at);

  return `
    <div class="deferred-item" data-deferred-id="${item.id}">
      <input type="checkbox" class="deferred-checkbox" data-action="check-deferred" data-deferred-id="${item.id}">
      <div class="deferred-info">
        <a href="${item.url}" target="_blank" rel="noopener" class="deferred-title" data-tooltip="${(item.title || '').replace(/"/g, '&quot;')}">
          ${faviconSrc ? `<img src="${faviconSrc}" alt="" style="width:14px;height:14px;vertical-align:-2px;margin-right:4px" class="favicon-img">` : ''}${escHtml(item.title || item.url)}
        </a>
        <div class="deferred-meta">
          <span>${domain}</span>
          <span>${ago}</span>
        </div>
      </div>
      <button class="deferred-dismiss" data-action="dismiss-deferred" data-deferred-id="${item.id}" data-tooltip="Dismiss">
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M6 18 18 6M6 6l12 12" /></svg>
      </button>
    </div>`;
}

/**
 * renderArchiveItem(item)
 *
 * Builds the HTML for a single item in the collapsed archive list.
 * Simpler than active items — just title link + date.
 */
function renderArchiveItem(item) {
  let domain = '';
  try { domain = new URL(item.url).hostname.replace(/^www\./, ''); } catch {}
  const ago = item.archived_at ? timeAgo(item.archived_at) : '';

  return `
    <div class="archive-item">
      <a href="${item.url}" target="_blank" rel="noopener" class="archive-item-title" data-tooltip="${(item.title || '').replace(/"/g, '&quot;')}">
        ${escHtml(item.title || item.url)}
      </a>
      <span class="archive-item-date">${ago}</span>
    </div>`;
}


/* ----------------------------------------------------------------
   MAIN DASHBOARD RENDERER

   renderStaticDashboard() — groups open tabs by domain.
   ---------------------------------------------------------------- */

/**
 * renderStaticDashboard()
 *
 * The main view. Loads instantly:
 * 1. Paint greeting + date
 * 2. Fetch open tabs from the extension
 * 3. Group tabs by domain (with landing pages pulled out)
 * 4. Render domain cards
 * 5. Update footer stats
 */
let lastTabSnapshot = '';
async function renderStaticDashboard() {
  // --- Header: greeting + date ---
  const greetingEl = document.getElementById('greeting');
  if (greetingEl) greetingEl.textContent = getGreeting();

  // ── Step 1: Fetch open tabs ───────────────────────────────────────────────
  await fetchOpenTabs();
  const realTabs = getRealTabs();

  const snapshot = JSON.stringify(openTabs.map(t => t.id + '\t' + t.url + '\t' + t.title).sort());
  if (snapshot === lastTabSnapshot) {
    const statTabs = document.getElementById('statTabs');
    if (statTabs) statTabs.textContent = openTabs.length;
    setTimeout(() => checkSwooshDupes(), 800);
    return;
  }
  lastTabSnapshot = snapshot;

  // ── Step 3: Group open tabs by domain ────────────────────────────────────
  // This is pure JavaScript — no AI, no API calls. We extract the hostname
  // from each tab URL and group them together.
  //
  // Special case: "landing pages" — homepages / inboxes / feeds that you
  // keep open out of habit. These get pulled into their own group so you
  // can close them all at once instead of hunting across domain cards.
  // Landing pages are homepages, inboxes, and feeds. A specific email thread
  // or a specific tweet is NOT a landing page — those belong with their domain.
  const LANDING_PAGE_PATTERNS = [
    { hostname: 'mail.google.com',  test: (p, h) => {
      // Only the inbox itself, not individual emails.
      // Gmail inbox URLs end with #inbox (no message ID after it)
      // Individual emails look like #inbox/FMfcgz...
      return !h.includes('#inbox/') && !h.includes('#sent/') && !h.includes('#search/');
    }},
    { hostname: 'x.com',                       pathExact: ['/home'] },
    { hostname: 'www.linkedin.com',            pathExact: ['/'] },
    { hostname: 'github.com',                  pathExact: ['/'] },
    { hostname: 'www.youtube.com',             pathExact: ['/'] },
  ];

  function isLandingPage(url) {
    try {
      const parsed = new URL(url);
      return LANDING_PAGE_PATTERNS.some(p => {
        if (parsed.hostname !== p.hostname) return false;
        if (p.test)       return p.test(parsed.pathname, url);
        if (p.pathPrefix) return parsed.pathname.startsWith(p.pathPrefix);
        if (p.pathExact)  return p.pathExact.includes(parsed.pathname);
        return parsed.pathname === '/';
      });
    } catch { return false; }
  }

  domainGroups = [];
  const groupMap = {};
  const landingTabs = [];

  for (const tab of realTabs) {
    try {
      // Check if this tab is a landing page first
      if (isLandingPage(tab.url)) {
        landingTabs.push(tab);
        continue;
      }

      // file:// URLs have no hostname — group them under "Local Files"
      let hostname;
      if (tab.url && tab.url.startsWith('file://')) {
        hostname = 'local-files';
      } else {
        hostname = new URL(tab.url).hostname;
      }
      if (!hostname) continue; // skip if still empty
      if (!groupMap[hostname]) {
        groupMap[hostname] = { domain: hostname, tabs: [] };
      }
      groupMap[hostname].tabs.push(tab);
    } catch {
      // Skip malformed URLs
    }
  }

  // Add landing pages as a special group at the end (if any)
  if (landingTabs.length > 0) {
    groupMap['__landing-pages__'] = { domain: '__landing-pages__', tabs: landingTabs };
  }

  // ── Extract pinned tabs into their own strip ───────────────────────────
  const pinnedTabs = [];
  for (const key of Object.keys(groupMap)) {
    const group = groupMap[key];
    const unpinned = [];
    for (const tab of group.tabs) {
      if (tab.pinned) {
        pinnedTabs.push(tab);
      } else {
        unpinned.push(tab);
      }
    }
    group.tabs = unpinned;
  }

  // ── Extract stale tabs into their own group ────────────────────────────
  const now = Date.now();
  const staleTabs = [];
  const staleUrlSet = new Set();
  for (const key of Object.keys(groupMap)) {
    const group = groupMap[key];
    const fresh = [];
    for (const tab of group.tabs) {
      const idle = tab.lastActivated ? (now - tab.lastActivated) : Infinity;
      if (idle >= STALE_THRESHOLD_MS && !tab.active && !tab.pinned) {
        staleTabs.push(tab);
        staleUrlSet.add(tab.url);
      } else {
        fresh.push(tab);
      }
    }
    group.tabs = fresh;
  }
  // Remove groups that became empty after extracting stale tabs
  for (const key of Object.keys(groupMap)) {
    if (groupMap[key].tabs.length === 0) delete groupMap[key];
  }
  currentStaleTabs = staleTabs;

  // Sort groups: landing pages first, then priority domains, then the rest by tab count
  const landingHostnames = new Set(LANDING_PAGE_PATTERNS.map(p => p.hostname));
  domainGroups = Object.values(groupMap).sort((a, b) => {
    const aIsLanding = a.domain === '__landing-pages__';
    const bIsLanding = b.domain === '__landing-pages__';
    if (aIsLanding !== bIsLanding) return aIsLanding ? -1 : 1;

    const aIsPriority = landingHostnames.has(a.domain);
    const bIsPriority = landingHostnames.has(b.domain);
    if (aIsPriority !== bIsPriority) return aIsPriority ? -1 : 1;

    return b.tabs.length - a.tabs.length;
  });

  // ── Step 4: Render domain cards ───────────────────────────────────────────
  const openTabsSection    = document.getElementById('openTabsSection');
  const openTabsMissionsEl = document.getElementById('openTabsMissions');
  const pinnedStripEl      = document.getElementById('pinnedStrip');

  // ── Pinned tabs strip ──────────────────────────────────────────────────
  if (pinnedStripEl) {
    if (pinnedTabs.length > 0) {
      const pinChips = pinnedTabs.map(tab => {
        const rawTitle = tab.title || '';
        const baseLabel = cleanTitle(smartTitle(stripTitleNoise(rawTitle), tab.url || ''), '');
        const label = aiTitleFor(tab.url, baseLabel);
        const safeUrl = (tab.url || '').replace(/"/g, '&quot;');
        const safeTitle = label.replace(/"/g, '&quot;');
        const letter = (baseLabel || rawTitle || '?')[0].toUpperCase();
        const fUrl = faviconUrl(tab.url, 32);
        return `<button class="pinned-chip" data-action="focus-tab" data-tab-url="${safeUrl}" data-tooltip="${safeTitle}">
          ${fUrl ? `<img class="pinned-chip-favicon favicon-img" src="${fUrl}" alt="" onerror="this.style.display='none';this.nextElementSibling.style.display='inline-flex'">` : ''}
          <span class="pinned-chip-fallback"${fUrl ? ' style="display:none"' : ''}>${letter}</span>
        </button>`;
      }).join('');
      pinnedStripEl.innerHTML = `<div class="pinned-strip-chips">${pinChips}</div>`;
      pinnedStripEl.style.display = 'flex';
    } else {
      pinnedStripEl.innerHTML = '';
      pinnedStripEl.style.display = 'none';
    }
  }

  // ── Smart grouping (Groq-powered, replaces domain groups when enabled) ─────
  // Gather all non-pinned, non-stale, non-landing tabs for clustering.
  if (groupingMode === 'smart' && aiApiKey) {
    const clusterable = [];
    for (const g of domainGroups) {
      if (g.domain === '__landing-pages__') continue;
      for (const t of g.tabs) clusterable.push(t);
    }
    const sig = tabSetSignature(clusterable);
    const cached = smartGroupCache[sig];
    if (cached) {
      const smart = rebuildGroupsFromCache(cached, clusterable);
      const landing = domainGroups.find(g => g.domain === '__landing-pages__');
      // Replace domainGroups so action handlers (close, dedupe, etc.) find them
      // by the same IDs used to render the cards.
      domainGroups = smart.map(g => ({ domain: g.name, displayName: g.name, tabs: g.tabs, isSmart: true }));
      if (landing) domainGroups.unshift(landing);
    } else {
      // Render domain groups now, refresh once Groq returns.
      smartGroupTabs(clusterable).then(result => {
        if (result && result.length > 0) {
          lastTabSnapshot = ''; // force re-render so smart groups take effect
          renderDashboard();
        }
      });
    }
  }
  const groupsToRender = domainGroups;

  const hasContent = groupsToRender.length > 0 || staleTabs.length > 0 || pinnedTabs.length > 0;
  if (openTabsSection) {
    if (groupsToRender.length > 0) {
      const cards = groupsToRender.map((g, idx) => renderDomainCard(g, idx));
      openTabsMissionsEl.innerHTML = distributeToColumns(cards, 3);
    } else if (!hasContent) {
      openTabsMissionsEl.innerHTML = `
        <div class="missions-empty-state">
          <div class="empty-title">Open a few tabs, then come back.</div>
          <div class="empty-subtitle">Swoosh groups your open tabs by site so you can see what you have and close what you don't.</div>
        </div>`;
    } else {
      openTabsMissionsEl.innerHTML = '';
    }
    openTabsSection.style.display = 'block';
  }

  // ── Stale tabs banner ──────────────────────────────────────────────────
  const staleBanner = document.getElementById('staleBanner');
  if (staleBanner) {
    if (staleTabs.length > 0) {
      const countEl = document.getElementById('staleBannerCount');
      const list    = document.getElementById('staleBannerList');
      const btn     = document.getElementById('staleBannerBtn');
      if (countEl) countEl.textContent = staleTabs.length;
      if (btn) btn.textContent = `Close all`;
      if (list) list.innerHTML = staleTabs.map(t => {
        const encoded = encodeURIComponent(t.url);
        const fUrl = faviconUrl(t.url, 16);
        const favicon = fUrl
          ? `<img src="${fUrl}" width="14" height="14" style="border-radius:2px;" class="favicon-img">`
          : '';
        return `<span class="stale-tab-chip" data-action="focus-tab" data-tab-url="${t.url}"><span class="stale-tab-keep" data-action="keep-stale-tab" data-stale-url="${encoded}" data-tooltip="Keep open">↗</span>${favicon}<span class="stale-tab-title">${escHtml(t.title || 'Untitled')}</span><span class="stale-tab-x" data-action="close-stale-tab" data-stale-url="${encoded}" data-tooltip="Close tab">&times;</span></span>`;
      }).join('');
      staleBanner.style.display = 'block';
    } else {
      staleBanner.style.display = 'none';
    }
  }

  // ── Footer stats ──────────────────────────────────────────────────────────
  const statTabs = document.getElementById('statTabs');
  if (statTabs) statTabs.textContent = openTabs.length;

  // ── Step 9: Render the "Saved for Later" checklist column ────────────────
  await renderDeferredColumn();

  // ── Step 10: Render daily digest section ────────────────────────────────
  renderDigestSection();

  // ── Step 11: Kick off AI title rewrites for tabs ─────────────────────────
  // Only when smart grouping is OFF — when grouping is on, the group name
  // gives enough context that the existing regex cleanup is sufficient.
  if (aiApiKey && groupingMode !== 'smart') {
    const tabItems = [];
    for (const group of domainGroups) {
      for (const tab of group.tabs) {
        if (tab.url && tab.title) tabItems.push({ url: tab.url, title: tab.title });
      }
    }
    for (const tab of pinnedTabs) {
      if (tab.url && tab.title) tabItems.push({ url: tab.url, title: tab.title });
    }
    enqueueAiRewrites(tabItems);
  }

  // ── Check for duplicate Swoosh tabs — delay until after page feels settled ──
  setTimeout(() => checkSwooshDupes(), 800);
}


/* ----------------------------------------------------------------
   DAILY DEV DIGEST — reads stored feed items and renders cards.
   ---------------------------------------------------------------- */

const DIGEST_SITE_FALLBACK = {
  "Simon Willison":  "https://simonwillison.net/",
  "Claude Blog":     "https://claude.com/blog",
  "Latent Space":    "https://www.latent.space/s/ainews",
  "Hugging Face":    "https://huggingface.co/blog",
  "Google AI":       "https://blog.google/technology/ai/",
  "Ars Technica AI": "https://arstechnica.com/ai/",
  "Hacker News":     "https://news.ycombinator.com/best?h=24",
  "GitHub Trending": "https://github.com/trending",
  "Verge AI":        "https://www.theverge.com/ai-artificial-intelligence",
  "TechCrunch AI":   "https://techcrunch.com/category/artificial-intelligence/",
};

async function renderDigestSection() {
  const section   = document.getElementById('digestSection');
  const list      = document.getElementById('digestList');
  const updatedEl = document.getElementById('digestUpdated');
  if (!section || !list) return;

  try {
    const [data, readData, pinnedData] = await Promise.all([
      chrome.storage.local.get('digest'),
      chrome.storage.local.get('digest_read'),
      chrome.storage.local.get('pinned_sources'),
    ]);
    const { items = [], generatedAt = null } = data.digest || {};
    const readSet = new Set(readData.digest_read || []);
    const pinnedSet = new Set(pinnedData.pinned_sources || []);
    if (updatedEl) {
      updatedEl.textContent = generatedAt ? `Updated ${_digestAgo(generatedAt)}` : 'Not yet refreshed';
    }
    if (items.length === 0) {
      list.innerHTML = '<div class="digest-empty">No digest yet — click ↻ to refresh</div>';
      return;
    }

    const groups = {};
    for (const item of items) {
      if (!groups[item.source]) groups[item.source] = [];
      groups[item.source].push(item);
    }

    const sourceCards = Object.entries(groups)
      .sort(([a], [b]) => {
        const pa = pinnedSet.has(a) ? 1 : 0;
        const pb = pinnedSet.has(b) ? 1 : 0;
        return pb - pa;
      })
      .map(([source, articles]) => {
      const siteUrl = DIGEST_SITE_FALLBACK[source] || '';
      const isPinned = pinnedSet.has(source);
      const rows = articles.map(a => {
        const isRead = readSet.has(a.link);
        const displayTitle = aiTitleFor(a.link, a.title);
        return `
        <div class="digest-article${isRead ? ' is-read' : ''}" data-href="${escHtml(a.link)}">
          <a class="digest-article-link" href="${escHtml(a.link)}" target="_blank" rel="noopener noreferrer">
            <span class="digest-article-title">${escHtml(displayTitle)}</span>
          </a>
          <span class="digest-age">${_digestAgo(a.publishedAt)}</span>
          <button class="digest-read-btn" data-link="${escHtml(a.link)}" aria-label="Mark as read" data-tooltip="${isRead ? 'Read' : 'Mark as read'}">
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M9 12.75 11.25 15 15 9.75M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" /></svg>
          </button>
        </div>`;
      }).join('');

      return `
        <div class="digest-source-card is-expanded" data-source="${escHtml(source)}">
          <div class="digest-source-top">
            ${isPinned ? `<span class="digest-pin-indicator" aria-label="Pinned source">${ICONS.pin}</span>` : ''}
            <a class="digest-badge" data-source="${escHtml(source)}" href="${escHtml(siteUrl)}" target="_blank" rel="noopener noreferrer">${escHtml(source)}</a>
            <span class="digest-count">${articles.length}</span>
            <div class="digest-source-actions">
              <button class="digest-expand-btn" aria-label="Toggle articles">
                <svg class="expand-chevron" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="m19.5 8.25-7.5 7.5-7.5-7.5" /></svg>
              </button>
            </div>
          </div>
          <div class="digest-articles">${rows}</div>
        </div>`;
    });
    list.innerHTML = distributeToColumns(sourceCards, 3);

    if (aiApiKey) {
      const articleItems = items
        .filter(it => it.link && it.title)
        .map(it => ({ url: it.link, title: it.title }));
      enqueueAiRewrites(articleItems);
    }
  } catch {
    section.style.display = 'none';
  }
}

function _digestAgo(ts) {
  const diff = Date.now() - ts;
  const d = Math.floor(diff / 86400000);
  const h = Math.floor(diff / 3.6e6);
  const m = Math.floor(diff / 60000);
  if (d >= 1) return `${d}d ago`;
  if (h >= 1) return `${h}h ago`;
  if (m >= 1) return `${m}m ago`;
  return 'just now';
}


/**
 * renderDashboard()
 *
 * Entry point — just calls renderStaticDashboard().
 * Guards against concurrent renders and coalesces back-to-back requests.
 */
let _renderInFlight = false;
let _renderQueued   = false;
async function renderDashboard() {
  if (_renderInFlight) {
    _renderQueued = true;
    return;
  }
  _renderInFlight = true;
  try {
    await renderStaticDashboard();
  } finally {
    _renderInFlight = false;
    if (_renderQueued) {
      _renderQueued = false;
      renderDashboard();
    }
  }
}


/* ----------------------------------------------------------------
   EVENT HANDLERS (using event delegation)

   Instead of attaching a listener to every button, we attach ONE
   listener to the whole document and check what was clicked.
   This is more efficient and works even after we re-render cards.

   Think of it like one security guard watching the whole building
   instead of one guard per door.
   ---------------------------------------------------------------- */

document.addEventListener('click', async (e) => {
  // Clicking a saved-for-later link: auto-dismiss it since it's now open
  const deferredLink = e.target.closest('.deferred-title');
  if (deferredLink) {
    const item = deferredLink.closest('.deferred-item');
    const id = item?.dataset.deferredId;
    if (id) {
      await updateDeferred(id, { dismissed: true });
      item.classList.add('removing');
      setTimeout(() => { item.remove(); renderDeferredColumn(); }, 300);
    }
    return; // let the link navigate normally
  }

  // Walk up the DOM from the clicked element to find the nearest
  // element with a data-action attribute
  const actionEl = e.target.closest('[data-action]');

  if (!actionEl) return;

  const action = actionEl.dataset.action;



  // Find the card element so we can animate it
  const card = actionEl.closest('.mission-card');

  // ---- expand-chips: show the hidden tabs in a card ----
  if (action === 'expand-chips') {
    const overflowContainer = actionEl.parentElement.querySelector('.page-chips-overflow');
    if (overflowContainer) {
      overflowContainer.style.display = 'contents';
      actionEl.remove();
    }
    return;
  }

  // ---- focus-tab: switch to a specific open tab ----
  if (action === 'focus-tab') {
    const tabUrl = actionEl.dataset.tabUrl;
    if (tabUrl) {
      await focusTabsByUrls([tabUrl]);
    }
    return;
  }

  // ---- close-single-tab: close one specific tab by URL ----
  if (action === 'close-single-tab') {
    e.stopPropagation();
    const tabUrl = actionEl.dataset.tabUrl;
    if (!tabUrl) return;

    await closeTabsByUrls([tabUrl], true);
    playCloseSound();

    // Remove the chip from the DOM with confetti
    const chip = actionEl.closest('.page-chip');
    if (chip) {
      const rect = chip.getBoundingClientRect();
      shootConfetti(rect.left + rect.width / 2, rect.top + rect.height / 2);
      chip.style.transition = 'opacity 0.2s, transform 0.2s';
      chip.style.opacity = '0';
      chip.style.transform = 'scale(0.8)';
      setTimeout(() => {
        chip.remove();
        // If this was the last tab in the card, remove the whole card
        const card = document.querySelector(`.mission-card:has(.mission-pages:empty)`);
        if (card) {
          animateCardOut(card);
        }
        // Also check for cards where only overflow/non-tab chips remain
        document.querySelectorAll('.mission-card').forEach(c => {
          const remainingTabs = c.querySelectorAll('.page-chip[data-action="focus-tab"]');
          if (remainingTabs.length === 0) {
            animateCardOut(c);
          }
        });
      }, 200);
    }

    showToast('Tab closed');
    return;
  }

  // ---- defer-single-tab: save one tab for later, then close it ----
  if (action === 'defer-single-tab') {
    e.stopPropagation(); // don't trigger the parent chip's focus-tab
    const tabUrl   = actionEl.dataset.tabUrl;
    const tabTitle = actionEl.dataset.tabTitle || tabUrl;
    if (!tabUrl) return;

    const matchingTab = openTabs.find(t => t.url === tabUrl);
    const faviconSrc = faviconUrl(tabUrl, 16);

    // Save to the deferred list in storage
    try {
      await insertDeferred({ url: tabUrl, title: tabTitle, favicon_url: faviconSrc });
    } catch (err) {
      console.error('[swoosh] Failed to defer tab:', err);
      showToast('Failed to save tab');
      return;
    }

    // Close the tab in the browser
    await closeTabsByUrls([tabUrl], true);

    // Animate the chip out
    const chip = actionEl.closest('.page-chip');
    if (chip) {
      chip.style.transition = 'opacity 0.2s, transform 0.2s';
      chip.style.opacity = '0';
      chip.style.transform = 'scale(0.8)';
      setTimeout(() => chip.remove(), 200);
    }

    showToast('Saved for later');
    // Refresh the deferred column to show the new item
    await renderDeferredColumn();
    return;
  }

  // ---- check-deferred: check off a deferred tab (mark as read) ----
  if (action === 'check-deferred') {
    const id = actionEl.dataset.deferredId;
    if (!id) return;

    try {
      await updateDeferred(id, { checked: true });
    } catch (err) {
      console.error('[swoosh] Failed to check deferred tab:', err);
      return;
    }

    // Animate the item: add strikethrough, then slide out
    const item = actionEl.closest('.deferred-item');
    if (item) {
      item.classList.add('checked');
      setTimeout(() => {
        item.classList.add('removing');
        setTimeout(() => {
          item.remove();
          renderDeferredColumn(); // refresh to update counts and archive
        }, 300);
      }, 800);
    }
    return;
  }

  // ---- dismiss-deferred: dismiss a deferred tab without reading ----
  if (action === 'dismiss-deferred') {
    const id = actionEl.dataset.deferredId;
    if (!id) return;

    try {
      await updateDeferred(id, { dismissed: true });
    } catch (err) {
      console.error('[swoosh] Failed to dismiss deferred tab:', err);
      return;
    }

    // Animate the item out
    const item = actionEl.closest('.deferred-item');
    if (item) {
      item.classList.add('removing');
      setTimeout(() => {
        item.remove();
        renderDeferredColumn(); // refresh counts and archive
      }, 300);
    }
    return;
  }

  // ---- keep-stale-tab: remove from stale list without closing the tab ----
  if (action === 'keep-stale-tab') {
    e.stopPropagation();
    const url = decodeURIComponent(actionEl.dataset.staleUrl || '');
    if (!url) return;
    currentStaleTabs = currentStaleTabs.filter(t => t.url !== url);
    const chip = actionEl.closest('.stale-tab-chip') || actionEl;
    chip.style.transition = 'opacity 0.3s, transform 0.3s';
    chip.style.opacity = '0';
    chip.style.transform = 'scale(0.8)';
    setTimeout(() => chip.remove(), 300);
    const countEl = document.getElementById('staleBannerCount');
    if (countEl) countEl.textContent = currentStaleTabs.length;
    if (currentStaleTabs.length === 0) {
      const staleBanner = document.getElementById('staleBanner');
      if (staleBanner) {
        staleBanner.style.transition = 'opacity 0.4s';
        staleBanner.style.opacity = '0';
        setTimeout(() => { staleBanner.style.display = 'none'; staleBanner.style.opacity = ''; }, 400);
      }
    }
    return;
  }

  // ---- close-stale-tab: close a single stale tab ----
  if (action === 'close-stale-tab') {
    e.stopPropagation();
    const url = decodeURIComponent(actionEl.dataset.staleUrl || '');
    if (!url) return;
    await closeTabsByUrls([url], true);
    playCloseSound();
    currentStaleTabs = currentStaleTabs.filter(t => t.url !== url);
    const chip = actionEl.closest('.stale-tab-chip') || actionEl;
    chip.style.transition = 'opacity 0.3s, transform 0.3s';
    chip.style.opacity = '0';
    chip.style.transform = 'scale(0.8)';
    setTimeout(() => chip.remove(), 300);
    const countEl = document.getElementById('staleBannerCount');
    if (countEl) countEl.textContent = currentStaleTabs.length;
    if (currentStaleTabs.length === 0) {
      const staleBanner = document.getElementById('staleBanner');
      if (staleBanner) {
        staleBanner.style.transition = 'opacity 0.4s';
        staleBanner.style.opacity = '0';
        setTimeout(() => { staleBanner.style.display = 'none'; staleBanner.style.opacity = '1'; staleBanner.style.transition = ''; }, 400);
      }
    }
    showToast('Closed stale tab');
    const statTabs = document.getElementById('statTabs');
    if (statTabs) statTabs.textContent = openTabs.length;
    return;
  }

  // ---- save-and-close-stale-tabs: bookmark all stale tabs, then close them ----
  if (action === 'save-and-close-stale-tabs') {
    if (currentStaleTabs.length === 0) return;
    const closable = currentStaleTabs.filter(t => !t.pinned);
    const skipped  = currentStaleTabs.length - closable.length;
    if (closable.length === 0) {
      showToast('No stale tabs to save (all pinned)');
      return;
    }

    const now = new Date();
    const dateLabel = now.toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' });
    const timeLabel = now.toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit' });
    const folderTitle = `Swoosh — Stale ${dateLabel} ${timeLabel}`;

    // Save to bookmarks FIRST. If anything fails, abort and leave tabs open.
    try {
      const folder = await chrome.bookmarks.create({ parentId: '2', title: folderTitle });
      for (const tab of closable) {
        await chrome.bookmarks.create({
          parentId: folder.id,
          title: tab.title || tab.url,
          url: tab.url,
        });
      }
    } catch (err) {
      console.error('[swoosh] Failed to save bookmarks:', err);
      showToast('Failed to save bookmarks — tabs not closed');
      return;
    }

    const urls = closable.map(t => t.url);
    await closeTabsByUrls(urls, true);
    playCloseSound();

    currentStaleTabs = currentStaleTabs.filter(t => t.pinned);
    if (currentStaleTabs.length === 0) {
      const staleBanner = document.getElementById('staleBanner');
      if (staleBanner) {
        staleBanner.style.transition = 'opacity 0.4s';
        staleBanner.style.opacity = '0';
        setTimeout(() => { staleBanner.style.display = 'none'; staleBanner.style.opacity = '1'; staleBanner.style.transition = ''; }, 400);
      }
    }

    let msg = `Saved ${urls.length} tab${urls.length !== 1 ? 's' : ''} to bookmarks & closed`;
    if (skipped > 0) msg += ` (skipped ${skipped} pinned)`;
    showToast(msg);

    const statTabs = document.getElementById('statTabs');
    if (statTabs) statTabs.textContent = openTabs.length;
    return;
  }

  // ---- close-stale-tabs: close all idle/stale tabs at once ----
  if (action === 'close-stale-tabs') {
    if (currentStaleTabs.length === 0) return;
    const closable = currentStaleTabs.filter(t => !t.pinned);
    const skipped  = currentStaleTabs.length - closable.length;
    const urls = closable.map(t => t.url);
    if (urls.length > 0) {
      await closeTabsByUrls(urls, true);
      playCloseSound();
    }
    currentStaleTabs = currentStaleTabs.filter(t => t.pinned);
    if (currentStaleTabs.length === 0) {
      const staleBanner = document.getElementById('staleBanner');
      if (staleBanner) {
        staleBanner.style.transition = 'opacity 0.4s';
        staleBanner.style.opacity = '0';
        setTimeout(() => { staleBanner.style.display = 'none'; staleBanner.style.opacity = '1'; staleBanner.style.transition = ''; }, 400);
      }
    }
    let msg = `Closed ${urls.length} stale tab${urls.length !== 1 ? 's' : ''}`;
    if (skipped > 0) msg += ` (skipped ${skipped} pinned)`;
    showToast(msg);
    const statTabs = document.getElementById('statTabs');
    if (statTabs) statTabs.textContent = openTabs.length;
    return;
  }

  // ---- close-domain-tabs: close all tabs in a static domain group ----
  if (action === 'close-domain-tabs') {
    const domainId = actionEl.dataset.domainId;
    // Find the group by its stable ID
    const group = domainGroups.find(g => {
      const id = 'domain-' + g.domain.replace(/[^a-z0-9]/g, '-');
      return id === domainId;
    });
    if (!group) return;

    const closable = group.tabs.filter(t => !t.pinned);
    const skipped  = group.tabs.length - closable.length;
    const urls = closable.map(t => t.url);
    const useExact = group.domain === '__landing-pages__';
    if (urls.length > 0) {
      await closeTabsByUrls(urls, useExact);
    }

    if (card) {
      playCloseSound();
      if (skipped === 0) animateCardOut(card);
    }

    if (skipped === 0) {
      const idx = domainGroups.indexOf(group);
      if (idx !== -1) domainGroups.splice(idx, 1);
    }

    const groupLabel = group.domain === '__landing-pages__' ? 'Homepages' : friendlyDomain(group.domain);
    let msg = `Closed ${urls.length} tab${urls.length !== 1 ? 's' : ''} from ${groupLabel}`;
    if (skipped > 0) msg += ` (${skipped} pinned kept)`;

    if (skipped === 0) {
      const undoUrls = [...urls];
      showUndoToast(msg, async () => {
        for (const url of undoUrls) await chrome.tabs.create({ url, active: false });
        await renderStaticDashboard();
      });
    } else {
      showToast(msg);
    }

    // Update footer tab count
    const statTabs = document.getElementById('statTabs');
    if (statTabs) statTabs.textContent = openTabs.length;
    return;
  }

  // ---- close-all-dupes: close every duplicate tab ----

  // ---- dedup-keep-one: close extras but keep one copy of each ----
  if (action === 'dedup-keep-one') {
    // URLs come from the button's data attribute (per-mission duplicates)
    const urlsEncoded = actionEl.dataset.dupeUrls || '';
    const urls = urlsEncoded.split(',').map(u => decodeURIComponent(u)).filter(Boolean);
    if (urls.length === 0) return;

    await closeDuplicates(urls, true);
    playCloseSound();
    await fetchOpenTabs();

    // Remove the dupe button
    actionEl.style.transition = 'opacity 0.2s';
    actionEl.style.opacity = '0';
    setTimeout(() => actionEl.remove(), 200);

    // Remove all (2x) badges and the "N duplicates" header badge from this card
    if (card) {
      card.querySelectorAll('.chip-dupe-badge').forEach(b => {
        b.style.transition = 'opacity 0.2s';
        b.style.opacity = '0';
        setTimeout(() => b.remove(), 200);
      });
      // Remove amber highlight from the card border
      card.classList.remove('has-amber-bar');
      card.classList.remove('has-amber-bar');
    }

    showToast(`Closed duplicates, kept one copy each`);
    return;
  }

  // ---- close-all-open-tabs: close every open tab (with confirmation) ----
  if (action === 'close-all-open-tabs') {
    if (!actionEl.dataset.confirmed) {
      const originalHtml = actionEl.innerHTML;
      actionEl.dataset.confirmed = 'pending';
      actionEl.innerHTML = `${ICONS.close} Sure? Click again`;
      actionEl.style.color = 'var(--accent-rose)';
      setTimeout(() => {
        delete actionEl.dataset.confirmed;
        actionEl.innerHTML = originalHtml;
        actionEl.style.color = '';
      }, 3000);
      return;
    }

    delete actionEl.dataset.confirmed;
    const allTabs = getRealTabs();
    const closable = allTabs.filter(t => !t.pinned);
    const skipped  = allTabs.length - closable.length;
    const allUrls = closable.map(t => t.url);
    await closeTabsByUrls(allUrls);
    playCloseSound();

    document.querySelectorAll('#openTabsMissions .mission-card').forEach(c => {
      shootConfetti(
        c.getBoundingClientRect().left + c.offsetWidth / 2,
        c.getBoundingClientRect().top + c.offsetHeight / 2
      );
      animateCardOut(c);
    });

    let msg = 'All tabs closed. Fresh start.';
    if (skipped > 0) msg = `Closed ${closable.length} tabs (skipped ${skipped} pinned)`;
    showToast(msg);
    return;
  }

});

// ---- Archive toggle — expand/collapse the archive section ----
document.addEventListener('click', (e) => {
  const toggle = e.target.closest('#archiveToggle');
  if (!toggle) return;

  toggle.classList.toggle('open');
  const body = document.getElementById('archiveBody');
  if (body) {
    body.classList.toggle('open');
  }
});

// ---- Archive search — filter archived items as user types (debounced) ----
let archiveSearchTimer = null;
document.addEventListener('input', (e) => {
  if (e.target.id !== 'archiveSearch') return;

  if (archiveSearchTimer) clearTimeout(archiveSearchTimer);
  archiveSearchTimer = setTimeout(async () => {
    const q = e.target.value.trim();
    const archiveList = document.getElementById('archiveList');
    if (!archiveList) return;

    if (q.length < 2) {
      try {
        const data = await getDeferred();
        archiveList.innerHTML = (data.archived || []).map(item => renderArchiveItem(item)).join('');
      } catch {}
      return;
    }

    try {
      const results = await searchDeferred(q);
      archiveList.innerHTML = results.map(item => renderArchiveItem(item)).join('')
        || '<div style="font-size:12px;color:var(--muted);padding:8px 0">No results</div>';
    } catch (err) {
      console.warn('[swoosh] Archive search failed:', err);
    }
  }, 300);
});


/* ----------------------------------------------------------------
   UNIVERSAL SEARCH DROPDOWN (tabs)
   Hotkeys: `/` or Cmd/Ctrl+K focuses the search input.
   Reuses: openTabs (app.js:29), focusTabsByUrls (app.js:79)
   ---------------------------------------------------------------- */

const USD_MAX_TAB_RESULTS = 4;

const USD_SEARCH_ICON_SVG = `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" width="16" height="16"><path stroke-linecap="round" stroke-linejoin="round" d="m21 21-5.197-5.197m0 0A7.5 7.5 0 1 0 5.196 5.196a7.5 7.5 0 0 0 10.607 10.607Z" /></svg>`;

let usdItems     = [];
let usdActiveIdx = -1;

function usdEscapeHtml(s) {
  return String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}

function usdEl() { return document.getElementById('universalSearchDropdown'); }
function usdInputEl() { return document.getElementById('googleSearchInput'); }

function usdIsGoogleSearchResultTab(url) {
  try {
    const u = new URL(url);
    // Skip google.* search pages — matching a search box query against a prior
    // Google search tab almost always produces noise (the tab's ?q= parameter
    // will coincidentally include the typed substring).
    if (!/(^|\.)google\./i.test(u.hostname)) return false;
    return u.pathname === '/search' || u.pathname === '/imgres' || u.pathname.startsWith('/search/');
  } catch { return false; }
}

function usdIsNewTabPage(url) {
  if (!url) return true;
  if (url === 'chrome://newtab/' || url === 'edge://newtab/' || url === 'about:newtab') return true;
  // Swoosh's own override page lives at chrome-extension://<id>/newtab.html
  if (url.startsWith('chrome-extension://') && url.includes('/newtab.html')) return true;
  return false;
}

// Match on hostname + pathname so the match is always visible in the rendered
// row. Matching the raw query string surfaced tabs whose ?q= parameter just
// happened to contain the substring.
function usdUrlKey(url) {
  try {
    const u = new URL(url);
    return (u.hostname + u.pathname).toLowerCase();
  } catch {
    return (url || '').toLowerCase();
  }
}

function usdEligibleTabs() {
  return openTabs.filter(t =>
    t.url && !usdIsGoogleSearchResultTab(t.url) && !usdIsNewTabPage(t.url)
  );
}

function usdSearchTabs(query) {
  const q = query.toLowerCase();
  const matches = usdEligibleTabs().filter(t => {
    const title = (t.title || '').toLowerCase();
    return title.includes(q) || usdUrlKey(t.url).includes(q);
  });
  matches.sort((a, b) => {
    const at = (a.title || '').toLowerCase().includes(q) ? 0 : 1;
    const bt = (b.title || '').toLowerCase().includes(q) ? 0 : 1;
    if (at !== bt) return at - bt;
    return (b.lastActivated || 0) - (a.lastActivated || 0);
  });
  return matches.slice(0, USD_MAX_TAB_RESULTS);
}

function usdRecentTabs() {
  return usdEligibleTabs()
    .slice()
    .sort((a, b) => (b.lastActivated || 0) - (a.lastActivated || 0))
    .slice(0, USD_MAX_TAB_RESULTS);
}


function usdPositionDropdown() {
  const el = usdEl();
  const input = usdInputEl();
  if (!el || !input) return;
  const rect = input.getBoundingClientRect();
  el.style.position = 'fixed';
  el.style.top  = (rect.bottom + 6) + 'px';
  el.style.left = rect.left + 'px';
  el.style.width = rect.width + 'px';
}

function usdRender(tabs, query) {
  usdItems = tabs.map(t => ({ type: 'tab', tab: t }));
  if (query) usdItems.push({ type: 'search', query });

  const el = usdEl();
  const input = usdInputEl();
  if (!el || !input) return;

  if (usdItems.length === 0) {
    el.hidden = true;
    el.innerHTML = '';
    input.setAttribute('aria-expanded', 'false');
    return;
  }

  usdPositionDropdown();

  const html = usdItems.map((item, idx) => {
    if (item.type === 'search') {
      return `<div class="usd-row usd-row-google" role="option" data-usd-idx="${idx}">`
           +   `<span class="usd-row-icon">${USD_SEARCH_ICON_SVG}</span>`
           +   `<span class="usd-row-text">Search web for <strong>${usdEscapeHtml(item.query)}</strong></span>`
           + `</div>`;
    }
    const t = item.tab;
    const fUrl = faviconUrl(t.url, 16);
    const favicon = fUrl
      ? `<img src="${usdEscapeHtml(fUrl)}" alt="">`
      : USD_SEARCH_ICON_SVG;
    let hostPath = '';
    try {
      const u = new URL(t.url);
      hostPath = u.hostname + (u.pathname && u.pathname !== '/' ? u.pathname : '');
    } catch {}
    return `<div class="usd-row usd-row-tab" role="option" data-usd-idx="${idx}">`
         +   `<span class="usd-row-icon">${favicon}</span>`
         +   `<span class="usd-row-text">${usdEscapeHtml(t.title || t.url)}`
         +     (hostPath ? `<span class="usd-row-url">— ${usdEscapeHtml(hostPath)}</span>` : '')
         +   `</span>`
         +   `<span class="usd-row-switch">Switch to Tab<span class="usd-row-switch-arrow">→</span></span>`
         + `</div>`;
  }).join('');

  el.innerHTML = html;
  el.hidden = false;
  input.setAttribute('aria-expanded', 'true');
  usdActiveIdx = 0;
  usdUpdateActive();
}

function usdUpdateActive() {
  const el = usdEl();
  if (!el) return;
  el.querySelectorAll('.usd-row').forEach((row, i) => {
    const active = i === usdActiveIdx;
    row.classList.toggle('is-active', active);
    if (active) row.scrollIntoView({ block: 'nearest' });
  });
}

function usdHide() {
  const el = usdEl();
  const input = usdInputEl();
  if (el) { el.hidden = true; el.innerHTML = ''; }
  if (input) input.setAttribute('aria-expanded', 'false');
  usdItems = [];
  usdActiveIdx = -1;
}

function usdShowRecent() {
  usdRender(usdRecentTabs());
}

function usdOnInput(e) {
  const query = e.target.value.trim();
  if (!query) { usdShowRecent(); return; }
  usdRender(usdSearchTabs(query), query);
}

function usdCommit(item) {
  if (!item) return;
  if (item.type === 'search') {
    usdSearch(item.query);
  } else {
    focusTabsByUrls([item.tab.url]);
    usdHide();
  }
}

function usdSearch(query) {
  if (!query) return;
  chrome.search.query({ text: query, disposition: 'CURRENT_TAB' });
  usdHide();
}

document.addEventListener('input', (e) => {
  if (e.target.id === 'googleSearchInput') usdOnInput(e);
});

document.addEventListener('focusin', (e) => {
  if (e.target.id !== 'googleSearchInput') return;
  const val = e.target.value.trim();
  if (val) {
    usdOnInput({ target: e.target });
  } else {
    usdShowRecent();
  }
});

document.addEventListener('keydown', (e) => {
  const input = usdInputEl();
  if (!input) return;

  if ((e.key === '/' || (e.key === 'k' && (e.metaKey || e.ctrlKey))) && document.activeElement !== input) {
    e.preventDefault();
    input.focus();
    input.select();
    return;
  }

  if (document.activeElement !== input) return;

  if (e.key === 'Escape') {
    const el = usdEl();
    if (el && !el.hidden) { usdHide(); e.preventDefault(); return; }
    input.value = '';
    input.blur();
    return;
  }

  const el = usdEl();
  if (e.key === 'Enter' && (!el || el.hidden || usdItems.length === 0)) {
    e.preventDefault();
    usdSearch(input.value.trim());
    return;
  }
  if (!el || el.hidden || usdItems.length === 0) return;

  if (e.key === 'ArrowDown') {
    e.preventDefault();
    usdActiveIdx = (usdActiveIdx + 1) % usdItems.length;
    usdUpdateActive();
  } else if (e.key === 'ArrowUp') {
    e.preventDefault();
    usdActiveIdx = (usdActiveIdx - 1 + usdItems.length) % usdItems.length;
    usdUpdateActive();
  } else if (e.key === 'Enter') {
    e.preventDefault();
    if (usdActiveIdx >= 0 && usdItems[usdActiveIdx]) {
      usdCommit(usdItems[usdActiveIdx]);
    } else {
      usdSearch(input.value.trim());
    }
  }
});

document.addEventListener('click', (e) => {
  const row = e.target.closest('.usd-row');
  if (row) {
    const idx = Number(row.dataset.usdIdx);
    if (Number.isFinite(idx)) usdCommit(usdItems[idx]);
    return;
  }
  if (!e.target.closest('.universal-search-wrap') && !e.target.closest('#universalSearchDropdown')) usdHide();
});

// Move dropdown to body so it escapes the .container stacking context
(function usdInit() {
  const el = document.getElementById('universalSearchDropdown');
  if (el && el.parentElement !== document.body) {
    document.body.appendChild(el);
  }
})();


/* ----------------------------------------------------------------
   THEME + PALETTE TOGGLES
   theme: 'light' | 'dark' (null = system default)
   palette: 'cool' | 'warm' (default cool)
   Persisted in localStorage.
   ---------------------------------------------------------------- */

function applyTheme(theme) {
  const root = document.documentElement;
  root.classList.remove('theme-light', 'theme-dark');
  root.classList.add(theme === 'dark' ? 'theme-dark' : 'theme-light');
}

function getEffectiveTheme() {
  const stored = localStorage.getItem('swoosh-theme');
  if (stored === 'light' || stored === 'dark') return stored;
  return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
}

function applyPalette(palette) {
  const root = document.documentElement;
  root.classList.remove('palette-cool', 'palette-warm');
  root.classList.add(palette === 'warm' ? 'palette-warm' : 'palette-cool');
}

function getEffectivePalette() {
  const stored = localStorage.getItem('swoosh-palette');
  return stored === 'warm' ? 'warm' : 'cool';
}

applyTheme(getEffectiveTheme());
applyPalette(getEffectivePalette());

document.getElementById('themeToggle')?.addEventListener('click', () => {
  const next = getEffectiveTheme() === 'dark' ? 'light' : 'dark';
  localStorage.setItem('swoosh-theme', next);
  applyTheme(next);
});

document.getElementById('paletteToggle')?.addEventListener('click', () => {
  const next = getEffectivePalette() === 'warm' ? 'cool' : 'warm';
  localStorage.setItem('swoosh-palette', next);
  applyPalette(next);
});

window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', (e) => {
  localStorage.removeItem('swoosh-theme');
  applyTheme(e.matches ? 'dark' : 'light');
});


/* ----------------------------------------------------------------
   INITIALIZE
   ---------------------------------------------------------------- */

// Single delegated listener for card expand/collapse — attached once, never leaks.
document.getElementById('openTabsMissions')?.addEventListener('click', (e) => {
  if (e.target.closest('button[data-action]')) return;
  const card = e.target.closest('.mission-card');
  if (card) card.classList.toggle('is-expanded');
});

// ── Stale threshold settings ──────────────────────────────────────────────────
function updateStaleTooltip() {
  const identity = document.getElementById('staleBannerIdentity');
  if (!identity) return;
  const h = staleThresholdHours;
  let label;
  if (h < 24) label = `${h} hour${h !== 1 ? 's' : ''}`;
  else if (h < 168) { const d = h / 24; label = `${d} day${d !== 1 ? 's' : ''}`; }
  else { const w = h / 168; label = `${w} week${w !== 1 ? 's' : ''}`; }
  identity.dataset.tooltip = `Tabs idle for ${label} or more`;
}

(async () => {
  const stored = await chrome.storage.local.get('staleThresholdHours');
  if (stored.staleThresholdHours) {
    staleThresholdHours = stored.staleThresholdHours;
    STALE_THRESHOLD_MS = staleThresholdHours * 60 * 60 * 1000;
  }
  // Mark active option
  document.querySelectorAll('.settings-opt').forEach(btn => {
    btn.classList.toggle('is-active', Number(btn.dataset.hours) === staleThresholdHours);
  });
  updateStaleTooltip();
})();

const settingsToggle = document.getElementById('settingsToggle');
const settingsPopover = document.getElementById('settingsPopover');
// Move to body so it floats above all stacking contexts
if (settingsPopover && settingsPopover.parentElement !== document.body) {
  document.body.appendChild(settingsPopover);
}

settingsToggle?.addEventListener('click', (e) => {
  e.stopPropagation();
  const isOpen = settingsPopover.classList.contains('is-open');
  if (!isOpen) {
    const rect = settingsToggle.getBoundingClientRect();
    settingsPopover.style.top = (rect.bottom + 8) + 'px';
    settingsPopover.style.right = (window.innerWidth - rect.right) + 'px';
  }
  settingsPopover.classList.toggle('is-open', !isOpen);
  settingsToggle.setAttribute('aria-expanded', String(!isOpen));
});

document.addEventListener('click', (e) => {
  if (settingsPopover?.classList.contains('is-open') && !e.target.closest('.settings-wrap, .settings-popover')) {
    settingsPopover.classList.remove('is-open');
    settingsToggle?.setAttribute('aria-expanded', 'false');
  }
});

// ── Groq API key settings ────────────────────────────────────────────────────
(function initGroqKeyUI() {
  const input  = document.getElementById('groqApiKeyInput');
  const save   = document.getElementById('groqApiKeySave');
  const status = document.getElementById('groqApiKeyStatus');
  if (!input || !save) return;

  function setStatus(msg, kind) {
    if (!status) return;
    status.textContent = msg;
    status.classList.remove('is-success', 'is-error');
    if (kind) status.classList.add(`is-${kind}`);
  }

  chrome.storage.local.get(AI_KEY_STORAGE).then(data => {
    const stored = data[AI_KEY_STORAGE] || '';
    if (stored) {
      input.value = stored;
      setStatus('Saved · AI rewrites active', 'success');
    } else {
      setStatus('Add a key to enable AI title cleanup', null);
    }
  });

  save.addEventListener('click', async () => {
    const val = input.value.trim();
    if (!val) {
      await chrome.storage.local.remove(AI_KEY_STORAGE);
      aiApiKey = '';
      await aiClearCache();
      setStatus('Key cleared', null);
      renderDashboard();
      return;
    }
    if (!val.startsWith('gsk_')) {
      setStatus('Groq keys start with gsk_', 'error');
      return;
    }
    await chrome.storage.local.set({ [AI_KEY_STORAGE]: val });
    aiApiKey = val;
    setStatus('Saved · rewriting titles…', 'success');
    renderDashboard();
  });

  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') { e.preventDefault(); save.click(); }
  });
})();

// ── Tab grouping mode toggle ─────────────────────────────────────────────────
function reflectGroupingMode() {
  document.querySelectorAll('#groupingOptions .settings-opt').forEach(b => {
    b.classList.toggle('is-active', b.dataset.grouping === groupingMode);
  });
}
document.getElementById('groupingOptions')?.addEventListener('click', async (e) => {
  const btn = e.target.closest('.settings-opt');
  if (!btn) return;
  const next = btn.dataset.grouping === 'smart' ? 'smart' : 'domain';
  if (next === groupingMode) return;
  groupingMode = next;
  // Clear poisoned/stale smart cache on every mode flip — cheap to rebuild
  smartGroupCache = {};
  await chrome.storage.local.remove(SMART_GROUP_CACHE_KEY);
  await chrome.storage.local.set({ [GROUPING_MODE_KEY]: next });
  reflectGroupingMode();
  lastTabSnapshot = '';
  renderDashboard();
});

document.getElementById('staleOptions')?.addEventListener('click', async (e) => {
  const btn = e.target.closest('.settings-opt');
  if (!btn) return;
  const hours = Number(btn.dataset.hours);
  staleThresholdHours = hours;
  STALE_THRESHOLD_MS = hours * 60 * 60 * 1000;
  await chrome.storage.local.set({ staleThresholdHours: hours });
  document.querySelectorAll('.settings-opt').forEach(b => {
    b.classList.toggle('is-active', Number(b.dataset.hours) === hours);
  });
  updateStaleTooltip();
  settingsPopover.classList.remove('is-open');
  settingsToggle?.setAttribute('aria-expanded', 'false');
  lastTabSnapshot = ''; // force full re-render so stale threshold is re-evaluated
  renderDashboard();
});

// ── Global tooltip engine ────────────────────────────────────────────────────
// Appended to body so it's never clipped by overflow:hidden on cards or banners.
(function initTooltip() {
  const tip = document.createElement('div');
  tip.id = 'swoosh-tooltip';
  document.body.appendChild(tip);

  let showTimer = null;

  function show(text, anchorEl) {
    tip.textContent = text;
    tip.classList.remove('is-visible');
    // Measure at opacity:0 so layout is correct before animating in
    tip.style.left = '-9999px';
    tip.style.top = '-9999px';
    // Force layout to get real dimensions
    const tw = tip.offsetWidth;
    const th = tip.offsetHeight;
    const r = anchorEl.getBoundingClientRect();
    const forceUp = anchorEl.dataset.tooltipPos === 'up';
    let left = r.left + r.width / 2 - tw / 2;
    let top = forceUp ? r.top - th - 6 : r.bottom + 6;
    // Clamp to viewport
    left = Math.max(8, Math.min(left, window.innerWidth - tw - 8));
    if (!forceUp && top + th > window.innerHeight - 8) top = r.top - th - 6;
    tip.style.left = left + 'px';
    tip.style.top = top + 'px';
    tip.classList.add('is-visible');
  }

  function hide() {
    clearTimeout(showTimer);
    tip.classList.remove('is-visible');
  }

  document.addEventListener('mouseover', (e) => {
    const el = e.target.closest('[data-tooltip]');
    if (!el) return;
    const text = el.dataset.tooltip;
    if (!text) return;
    clearTimeout(showTimer);
    showTimer = setTimeout(() => show(text, el), 600);
  });

  document.addEventListener('mouseout', (e) => {
    const el = e.target.closest('[data-tooltip]');
    if (!el) return;
    // Only hide if moving outside the element entirely
    if (!el.contains(e.relatedTarget)) hide();
  });

  // Hide on scroll/click so stale tooltips don't linger
  document.addEventListener('scroll', hide, { capture: true, passive: true });
  document.addEventListener('mousedown', hide);
})();

document.getElementById('digestList')?.addEventListener('click', async (e) => {
  const readBtn = e.target.closest('.digest-read-btn');
  if (readBtn) {
    e.preventDefault();
    e.stopPropagation();
    const article = readBtn.closest('.digest-article');
    const link = readBtn.dataset.link;
    if (article && link) {
      const wasRead = article.classList.toggle('is-read');
      readBtn.dataset.tooltip = wasRead ? 'Read' : 'Mark as read';
      const rd = await chrome.storage.local.get('digest_read');
      const arr = rd.digest_read || [];
      if (wasRead && !arr.includes(link)) {
        arr.push(link);
        await chrome.storage.local.set({ digest_read: arr });
      } else if (!wasRead) {
        await chrome.storage.local.set({ digest_read: arr.filter(l => l !== link) });
      }
    }
    return;
  }
  const articleLink = e.target.closest('.digest-article-link');
  if (articleLink) {
    const article = articleLink.closest('.digest-article');
    if (article) {
      article.classList.add('is-read');
      const href = articleLink.getAttribute('href');
      if (href) {
        const rd = await chrome.storage.local.get('digest_read');
        const arr = rd.digest_read || [];
        if (!arr.includes(href)) {
          arr.push(href);
          await chrome.storage.local.set({ digest_read: arr });
        }
      }
    }
    return;
  }
  const badge = e.target.closest('.digest-badge');
  if (badge) return;
  const card = e.target.closest('.digest-source-card');
  if (card) card.classList.toggle('is-expanded');
});

async function _togglePinSource(source) {
  const pinned = await chrome.storage.local.get('pinned_sources');
  const arr = pinned.pinned_sources || [];
  const idx = arr.indexOf(source);
  if (idx >= 0) {
    arr.splice(idx, 1);
  } else {
    arr.push(source);
  }
  await chrome.storage.local.set({ pinned_sources: arr });
  renderDigestSection();
}

document.getElementById('digestList')?.addEventListener('contextmenu', async (e) => {
  const card = e.target.closest('.digest-source-card');
  if (!card) return;
  const source = card.dataset.source;
  if (!source) return;

  e.preventDefault();
  e.stopPropagation();

  const oldMenu = document.querySelector('.digest-context-menu');
  if (oldMenu) oldMenu.remove();

  const pinned = await chrome.storage.local.get('pinned_sources');
  const pinnedSet = new Set(pinned.pinned_sources || []);
  const isPinned = pinnedSet.has(source);

  const menu = document.createElement('div');
  menu.className = 'digest-context-menu';
  menu.innerHTML = `
    <button class="digest-context-item" data-action="toggle-pin" data-source="${escHtml(source)}">
      <span class="digest-context-icon">${ICONS.pin}</span>
      <span>${isPinned ? 'Unpin source' : 'Pin source'}</span>
    </button>
  `;
  menu.style.left = `${e.offsetX + 8}px`;
  menu.style.top  = `${e.offsetY}px`;

  menu.querySelector('.digest-context-item')?.addEventListener('click', async (ev) => {
    ev.preventDefault();
    ev.stopPropagation();
    await _togglePinSource(source);
    menu.remove();
  });

  card.appendChild(menu);
});

document.addEventListener('click', () => {
  const menu = document.querySelector('.digest-context-menu');
  if (menu) menu.remove();
});

document.getElementById('digestRefresh')?.addEventListener('click', async () => {
  const btn = document.getElementById('digestRefresh');
  if (btn) { btn.disabled = true; btn.textContent = '…'; }
  try {
    await chrome.runtime.sendMessage({ type: 'REFRESH_DIGEST' });
    await renderDigestSection();
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = '↻'; }
  }
});

startClock();
Promise.all([loadAiState(), loadGroupingState()]).then(() => {
  reflectGroupingMode();
  renderDashboard();
});

// Refresh digest on every new tab open; re-render when feeds return
chrome.runtime.sendMessage({ type: 'REFRESH_DIGEST' })
  .then(() => renderDigestSection())
  .catch(() => {});
